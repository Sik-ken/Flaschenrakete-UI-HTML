/* Zahlenformatierung und -parsing (Port von Fmt.java).
 *
 * Ausgaben nutzen immer den Punkt als Dezimaltrenner; Eingaben duerfen das
 * Komma verwenden. g()/repr() verhalten sich wie Pythons "%g" bzw. repr(float),
 * damit gespeicherte Dateien und Referenzwerte zu Python/Java passen.
 */
(function (FR) {
    "use strict";

    /** Ziffern (prec Stück) und Zehnerexponent von |x| mit Half-Even-Rundung auf dem exakten Wert. */
    function rundeZiffern(ax, prec) {
        var s = ax.toExponential(prec - 1);            // korrekt gerundet, exakte Ties werden aufgerundet
        var lang = ax.toExponential(Math.min(100, prec - 1 + 40));
        var teile = lang.split("e");
        var mant = teile[0].replace(".", "");
        var rest = mant.slice(prec);
        if (/^50*$/.test(rest)) {                      // exakter Tie: Half-Even wie Python
            var abgeschnitten = mant.slice(0, prec);
            var letzte = abgeschnitten.charCodeAt(prec - 1) - 48;
            if (letzte % 2 === 0) {
                return { ziffern: abgeschnitten, exp10: parseInt(teile[1], 10) };
            }
        }
        var t = s.split("e");
        return { ziffern: t[0].replace(".", ""), exp10: parseInt(t[1], 10) };
    }

    function ohneEndnullen(ziffern) {
        var ende = ziffern.length;
        while (ende > 1 && ziffern.charAt(ende - 1) === "0") ende--;
        return ziffern.slice(0, ende);
    }

    function nullen(n) {
        return n > 0 ? new Array(n + 1).join("0") : "";
    }

    /** Dezimalpunkt so setzen, dass decpt Stellen davor stehen (Wert = 0.ziffern * 10^decpt). */
    function punktSetzen(ziffern, decpt) {
        if (decpt <= 0) return "0." + nullen(-decpt) + ziffern;
        if (decpt >= ziffern.length) return ziffern + nullen(decpt - ziffern.length);
        return ziffern.slice(0, decpt) + "." + ziffern.slice(decpt);
    }

    function exponent(e) {
        var a = Math.abs(e);
        return (e < 0 ? "-" : "+") + (a < 10 ? "0" + a : String(a));
    }

    /** Entspricht Pythons f"{x:.<prec>g}" (ohne '#': Nullen werden gekuerzt). */
    function g(x, prec) {
        if (isNaN(x)) return "nan";
        if (x === Infinity) return "inf";
        if (x === -Infinity) return "-inf";
        if (x === 0) return (1 / x < 0) ? "-0" : "0";
        var r = rundeZiffern(Math.abs(x), prec);
        var ziffern = ohneEndnullen(r.ziffern);
        var vz = x < 0 ? "-" : "";
        if (r.exp10 < -4 || r.exp10 >= prec) {
            var mant = ziffern.length > 1 ? ziffern.charAt(0) + "." + ziffern.slice(1) : ziffern;
            return vz + mant + "e" + exponent(r.exp10);
        }
        return vz + punktSetzen(ziffern, r.exp10 + 1);
    }

    /** Entspricht Pythons f"{x:.6g}". */
    function g6(x) {
        return g(x, 6);
    }

    /** Entspricht Pythons repr(float): kuerzeste Darstellung, die zurueckgelesen identisch ist. */
    function repr(x) {
        if (isNaN(x)) return "nan";
        if (x === Infinity) return "inf";
        if (x === -Infinity) return "-inf";
        if (x === 0) return (1 / x < 0) ? "-0.0" : "0.0";
        var t = Math.abs(x).toExponential().split("e");   // kuerzeste Ziffernfolge
        var ziffern = ohneEndnullen(t[0].replace(".", ""));
        var decpt = parseInt(t[1], 10) + 1;               // Wert = 0.ziffern * 10^decpt
        var vz = x < 0 ? "-" : "";
        if (decpt <= -4 || decpt > 16) {
            var mant = ziffern.length > 1 ? ziffern.charAt(0) + "." + ziffern.slice(1) : ziffern;
            return vz + mant + "e" + exponent(decpt - 1);
        }
        var s = punktSetzen(ziffern, decpt);
        return vz + (s.indexOf(".") >= 0 ? s : s + ".0");
    }

    /** Festkommazahl mit n Nachkommastellen (wie %.nf), optional auf Mindestbreite rechtsbuendig aufgefuellt. */
    function fest(x, n, breite, mitVorzeichen) {
        var s = isFinite(x) ? x.toFixed(n) : (isNaN(x) ? "NaN" : (x > 0 ? "Infinity" : "-Infinity"));
        if (mitVorzeichen && x >= 0 && !/^-/.test(s)) s = "+" + s;
        return breite ? links(s, breite) : s;
    }

    /** Text rechtsbuendig auf Mindestbreite auffuellen (Leerzeichen links). */
    function links(s, breite) {
        s = String(s);
        return s.length >= breite ? s : new Array(breite - s.length + 1).join(" ") + s;
    }

    /** Text linksbuendig auf Mindestbreite auffuellen (Leerzeichen rechts). */
    function rechts(s, breite) {
        s = String(s);
        return s.length >= breite ? s : s + new Array(breite - s.length + 1).join(" ");
    }

    var ZAHL = /^[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$/;

    /** Wie Pythons _parse_float: Komma als Dezimaltrenner erlaubt. Wirft Error bei ungueltigem Text. */
    function parse(text, feldname) {
        var t = String(text).trim().replace(/,/g, ".");
        var wert = NaN;
        if (ZAHL.test(t)) wert = Number(t);
        if (!isFinite(wert)) {
            throw new Error("Ungültiger Zahlenwert bei '" + feldname + "': '" + t + "'");
        }
        return wert;
    }

    /** Wie Pythons _parse_float_list: Trennzeichen ';'. */
    function parseList(text, feldname) {
        var werte = [];
        var teile = String(text).trim().split(";");
        for (var i = 0; i < teile.length; i++) {
            var teil = teile[i].trim();
            if (teil !== "") werte.push(parse(teil, feldname));
        }
        if (werte.length === 0) {
            throw new Error("Liste '" + feldname + "' darf nicht leer sein.");
        }
        return werte;
    }

    /** Liste als "a; b; c" mit g6. */
    function joinList(werte) {
        var teile = [];
        for (var i = 0; i < werte.length; i++) teile.push(g6(werte[i]));
        return teile.join("; ");
    }

    FR.Fmt = {
        g: g, g6: g6, repr: repr, fest: fest, links: links, rechts: rechts,
        parse: parse, parseList: parseList, joinList: joinList
    };
})(globalThis.FR = globalThis.FR || {});
