/* Gemeinsame Bausteine der Oberflaeche (ersetzt JOptionPane, JFileChooser, SwingWorker-Pausen).
 * Alles ohne Server und ohne Module: laeuft direkt aus dem Dateisystem (file://).
 */
(function (FR) {
    "use strict";

    // ------------------------------------------------------------------
    // Kleine DOM-Helfer
    // ------------------------------------------------------------------
    /** Element erzeugen: el("td", {class: "x"}, "Text", weitereKinder ...). */
    function el(tag, attribute, kinder) {
        var e = document.createElement(tag);
        var k;
        if (attribute) {
            for (k in attribute) {
                if (k === "class") e.className = attribute[k];
                else e.setAttribute(k, attribute[k]);
            }
        }
        for (var i = 2; i < arguments.length; i++) {
            var kind = arguments[i];
            if (kind === null || kind === undefined) continue;
            e.appendChild(typeof kind === "string" ? document.createTextNode(kind) : kind);
        }
        return e;
    }

    /** Kurze Pause, damit der Browser zwischendurch zeichnen und Eingaben verarbeiten kann. */
    function pause() {
        return new Promise(function (resolve) { setTimeout(resolve, 0); });
    }

    /** Ruft fn auf, sobald sich die Groesse des Elements aendert (auch beim Einblenden eines Tabs). */
    function beiGroessenaenderung(element, fn) {
        if (typeof ResizeObserver !== "undefined") {
            new ResizeObserver(function () { fn(); }).observe(element);
        } else {
            window.addEventListener("resize", fn);
        }
    }

    // ------------------------------------------------------------------
    // Meldungsfenster (ersetzt JOptionPane.showMessageDialog)
    // ------------------------------------------------------------------
    /**
     * Zeigt eine Meldung mit Titel. art: "fehler" | "info" | "warnung".
     * Liefert ein Promise, das beim Schliessen aufgeloest wird.
     */
    function meldung(titel, text, art) {
        return new Promise(function (resolve) {
            var modal = document.getElementById("modal");
            var box = modal.querySelector(".modal-box");
            var vorher = document.activeElement;
            document.getElementById("modalTitel").textContent = titel;
            document.getElementById("modalText").textContent = text;
            box.className = "modal-box " + (art || "info");
            modal.hidden = false;
            var ok = document.getElementById("modalOk");
            ok.focus();

            function schliessen() {
                modal.hidden = true;
                ok.removeEventListener("click", schliessen);
                document.removeEventListener("keydown", taste, true);
                if (vorher && vorher.focus) vorher.focus();
                resolve();
            }
            function taste(e) {
                if (e.key === "Escape" || e.key === "Enter") {
                    e.preventDefault();
                    e.stopPropagation();
                    schliessen();
                } else if (e.key === "Tab") {
                    e.preventDefault();          // Fokus bleibt im Fenster (einziger Knopf)
                }
            }
            ok.addEventListener("click", schliessen);
            document.addEventListener("keydown", taste, true);
        });
    }

    // ------------------------------------------------------------------
    // Datei speichern / laden (ersetzt JFileChooser)
    // ------------------------------------------------------------------
    /**
     * Speichert Text als Datei. Chrome/Edge: Dialog "Speichern unter"; sonst (Safari, Firefox):
     * normaler Download in den Download-Ordner des Browsers.
     * opts: {name, text, mime, beschreibung, endung}
     * Ergebnis: {ok: true, name, download: bool} oder {ok: false} bei Abbruch.
     */
    async function dateiSpeichern(opts) {
        var blob = new Blob([opts.text], { type: opts.mime + ";charset=utf-8" });
        if (typeof window.showSaveFilePicker === "function") {
            try {
                var accept = {};
                accept[opts.mime] = [opts.endung];
                var handle = await window.showSaveFilePicker({
                    suggestedName: opts.name,
                    types: [{ description: opts.beschreibung, accept: accept }]
                });
                var w = await handle.createWritable();
                await w.write(blob);
                await w.close();
                return { ok: true, name: handle.name, download: false };
            } catch (e) {
                if (e && e.name === "AbortError") return { ok: false };
                // andere Fehler (z. B. gesperrt): auf normalen Download zurueckfallen
            }
        }
        var url = URL.createObjectURL(blob);
        var a = document.createElement("a");
        a.href = url;
        a.download = opts.name;
        a.style.display = "none";
        document.body.appendChild(a);
        a.click();
        setTimeout(function () {
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }, 1000);
        return { ok: true, name: opts.name, download: true };
    }

    /**
     * Oeffnet den Dateiwaehler und liest die gewaehlte Datei als UTF-8-Text.
     * Ergebnis: {name, text}, oder null wenn nichts gewaehlt wurde. Muss aus einem Klick-Ereignis aufgerufen werden.
     */
    function dateiLaden(akzeptiere) {
        return new Promise(function (resolve, reject) {
            var eingabe = document.createElement("input");
            eingabe.type = "file";
            eingabe.accept = akzeptiere;
            eingabe.style.display = "none";
            document.body.appendChild(eingabe);
            function aufraeumen() {
                if (eingabe.parentNode) eingabe.parentNode.removeChild(eingabe);
            }
            eingabe.addEventListener("change", function () {
                var datei = eingabe.files && eingabe.files[0];
                if (!datei) { aufraeumen(); resolve(null); return; }
                var leser = new FileReader();
                leser.onload = function () {
                    aufraeumen();
                    resolve({ name: datei.name, text: String(leser.result) });
                };
                leser.onerror = function () {
                    aufraeumen();
                    reject(new Error("Die Datei konnte nicht gelesen werden."));
                };
                leser.readAsText(datei, "UTF-8");
            });
            eingabe.addEventListener("cancel", function () {
                aufraeumen();
                resolve(null);
            });
            eingabe.click();
        });
    }

    FR.Ui = {
        el: el, pause: pause, beiGroessenaenderung: beiGroessenaenderung,
        meldung: meldung, dateiSpeichern: dateiSpeichern, dateiLaden: dateiLaden
    };
})(globalThis.FR = globalThis.FR || {});
