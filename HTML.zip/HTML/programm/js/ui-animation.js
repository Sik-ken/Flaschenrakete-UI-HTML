/* Tab 4: Flugsimulation (Brennen, Steigen, Fallen) einer in Tab 3 berechneten Duese als einfache
 * Canvas-Animation mit Live-Kontrollpanel (Port von AnimationTab.java). Die seitliche Bewegung ist
 * rein zur Darstellung; Hoehe und Geschwindigkeit stammen aus dem 1D-Modell.
 */
(function (FR) {
    "use strict";

    var Fmt = FR.Fmt;
    var Modell = FR.Modell;
    var el = FR.Ui.el;

    var CANVAS_W = 760;
    var CANVAS_H = 420;
    var X0 = 60;
    var Y_BODEN = CANVAS_H - 50;
    var Y_TOP = 25;
    var HORIZ_RANGE = CANVAS_W - X0 - 90;
    var SLIDER_MAX = 10000;

    var ergebnis = null;
    var traj = null;
    var tListe = [];
    var duesenOptionen = {};          // Beschriftung -> d in mm

    var laeuft = false;
    var pausiert = false;
    var cursorT = 0.0;
    var aktuellerIndex = -1;
    var rafId = null;
    var letzterZeitstempel = 0;

    var duesenBox, tempoSlider, tempoLabel, startBtn, pauseBtn, resetBtn, fortschritt, statusEl;
    var canvas, ctx, zeitSlider;
    var zeitL, hoeheL, geschwL, druckL, tempL, schubL;
    var skala = 1;                    // Verhaeltnis Zeichenpixel zu logischen 760x420-Einheiten
    var cssBreite = CANVAS_W;

    function tempo() {
        return tempoSlider.value / 100.0;
    }

    // ------------------------------------------------------------------
    // Ergebnisse aus Tab 3 uebernehmen
    // ------------------------------------------------------------------
    function setErgebnis(res) {
        ergebnis = res;
        var best = Modell.optimum(res.erg);
        var bisheriger = duesenBox.value;
        duesenOptionen = {};
        duesenBox.textContent = "";
        var empfehlung = null;
        res.erg.forEach(function (e) {
            var label = Fmt.g6(e.d_mm) + " mm";
            if (e === best) {
                label += " (Optimum)";
                empfehlung = label;
            }
            duesenOptionen[label] = e.d_mm;
            duesenBox.appendChild(el("option", { value: label }, label));
        });
        if (bisheriger && Object.prototype.hasOwnProperty.call(duesenOptionen, bisheriger)) {
            duesenBox.value = bisheriger;
        } else if (empfehlung !== null) {
            duesenBox.value = empfehlung;
        }
    }

    // ------------------------------------------------------------------
    // Ablaufsteuerung
    // ------------------------------------------------------------------
    function schleifeStarten() {
        if (rafId === null) {
            letzterZeitstempel = 0;
            rafId = requestAnimationFrame(schritt);
        }
    }

    function schleifeStoppen() {
        if (rafId !== null) {
            cancelAnimationFrame(rafId);
            rafId = null;
        }
    }

    /** Ein Bild der Schleife: Simulationszeit laeuft mit tempo() x Echtzeit. */
    function schritt(jetzt) {
        rafId = null;
        if (!laeuft || pausiert || !traj) return;
        var dt = letzterZeitstempel ? Math.min((jetzt - letzterZeitstempel) / 1000.0, 0.1) : 0.0;
        letzterZeitstempel = jetzt;
        tick(dt);
        if (laeuft && !pausiert) rafId = requestAnimationFrame(schritt);
    }

    function tick(dt) {
        cursorT += dt * tempo();
        if (cursorT >= traj.t_landung) {
            rendern(traj.punkte.length - 1);
            laeuft = false;
            schleifeStoppen();
            pauseBtn.disabled = true;
            statusEl.textContent = landeText();
            return;
        }
        rendern(indexBei(cursorT));
    }

    function landeText() {
        return "Gelandet nach " + Fmt.fest(traj.t_landung, 2) + " s.";
    }

    /** Entspricht bisect_left auf der Zeitliste, begrenzt auf gueltige Indizes. */
    function indexBei(t) {
        var lo = 0, hi = tListe.length;
        while (lo < hi) {
            var mid = (lo + hi) >>> 1;
            if (tListe[mid] < t) lo = mid + 1;
            else hi = mid;
        }
        return Math.min(Math.max(lo, 0), tListe.length - 1);
    }

    function wiedergabeStoppen() {
        laeuft = false;
        pausiert = false;
        schleifeStoppen();
    }

    async function startGeklickt() {
        if (!ergebnis) {
            await FR.Ui.meldung("Keine Ergebnisse", "Bitte zuerst im Tab „Berechnung“ rechnen.", "info");
            return;
        }
        var label = duesenBox.value;
        if (!label || !Object.prototype.hasOwnProperty.call(duesenOptionen, label)) {
            await FR.Ui.meldung("Keine Düse gewählt", "Bitte eine Düse auswählen.", "info");
            return;
        }
        var dMm = duesenOptionen[label];

        wiedergabeStoppen();
        aktuellerIndex = -1;
        zeichnen();

        startBtn.disabled = true;
        pauseBtn.disabled = true;
        fortschritt.hidden = false;
        statusEl.textContent = "Flugbahn wird berechnet...";
        await FR.Ui.pause();
        try {
            flugbahnBereit(Modell.flugbahn(ergebnis.par, dMm / 1000.0));
        } catch (e) {
            statusEl.textContent = "Fehler bei der Flugbahnberechnung.";
            await FR.Ui.meldung("Fehler bei der Flugbahnberechnung", String(e && e.message), "fehler");
        } finally {
            fortschritt.hidden = true;
            startBtn.disabled = false;
        }
    }

    function flugbahnBereit(f) {
        traj = f;
        tListe = f.punkte.map(function (p) { return p.t; });
        cursorT = 0.0;
        aktuellerIndex = -1;
        zeitSlider.disabled = false;

        pauseBtn.textContent = "Pause";
        pauseBtn.disabled = false;
        statusEl.textContent = "Animation läuft...";
        laeuft = true;
        pausiert = false;
        rendern(0);
        schleifeStarten();
    }

    function pauseGeklickt() {
        if (!traj) return;
        if (laeuft && !pausiert) {
            pausiert = true;
            schleifeStoppen();
            pauseBtn.textContent = "Weiter";
            statusEl.textContent = "Pausiert.";
        } else if (pausiert) {
            pausiert = false;
            laeuft = true;
            pauseBtn.textContent = "Pause";
            statusEl.textContent = "Animation läuft...";
            schleifeStarten();
        }
    }

    function zeitSliderBewegt() {
        if (!traj) return;
        wiedergabeStoppen();
        pausiert = true;
        pauseBtn.textContent = "Weiter";
        pauseBtn.disabled = false;
        var t = zeitSlider.value / SLIDER_MAX * traj.t_landung;
        cursorT = t;
        rendern(indexBei(t));
        statusEl.textContent = t >= traj.t_landung - 1e-9 ? landeText() : "Pausiert (manuell).";
    }

    function resetGeklickt() {
        wiedergabeStoppen();
        cursorT = 0.0;
        pauseBtn.textContent = "Pause";
        pauseBtn.disabled = true;
        startBtn.disabled = false;
        aktuellerIndex = -1;
        if (traj) {
            rendern(0);
            statusEl.textContent = "Bereit (zurückgesetzt).";
        } else {
            zeichnen();
            statusEl.textContent = "Bereit.";
        }
    }

    function sliderSetzen(t) {
        zeitSlider.value = Math.round(t / traj.t_landung * SLIDER_MAX);
    }

    /** Zeigt einen Punkt der Flugbahn in Zeichenflaeche, Kontrollpanel und Zeitregler. */
    function rendern(index) {
        aktuellerIndex = index;
        var p = traj.punkte[index];
        zeichnen();

        zeitL.textContent = Fmt.fest(p.t, 2) + " s";
        hoeheL.textContent = Fmt.fest(p.h, 2) + " m";
        geschwL.textContent = Fmt.fest(p.v, 2) + " m/s";
        // Nach Brennschluss enthalten die Punkte bereits Umgebungsdruck/-temperatur und Schub 0.
        druckL.textContent = Fmt.fest(p.p / 1e5, 2) + " bar";
        tempL.textContent = Fmt.fest(p.T, 0) + " K";
        schubL.textContent = Fmt.fest(p.F, 1) + " N";
        sliderSetzen(p.t);
    }

    // ------------------------------------------------------------------
    // Zeichenflaeche (logische Einheiten 760 x 420, per Transformation skaliert)
    // ------------------------------------------------------------------
    /** Passt die Zeichenpixel an die aktuelle Anzeigebreite an (scharf auch auf Retina-Displays). */
    function groesseAnpassen() {
        var w = canvas.clientWidth || CANVAS_W;
        var dpr = window.devicePixelRatio || 1;
        var bw = Math.max(1, Math.round(w * dpr));
        var bh = Math.max(1, Math.round(bw * CANVAS_H / CANVAS_W));
        if (canvas.width !== bw || canvas.height !== bh) {
            canvas.width = bw;
            canvas.height = bh;
        }
        skala = bw / CANVAS_W;
        cssBreite = w;
    }

    /** Bildschirmposition (x, Fusspunkt der Rakete y) eines Flugpunkts. */
    function position(p, hMaxSkala) {
        // X-Position rein zur Darstellung: proportional zum Zeitfortschritt innerhalb der jeweiligen
        // Phase (Brennen/Steigen bis t_apex, Fallen danach bis t_landung). Die Hoehe (Y) ist der
        // echte, physikalische Wert; es ergibt sich eine gekruemmte, symmetrische Bahn.
        var tApex = traj.t_apex !== null ? traj.t_apex : 1e-9;
        var frac;
        if (p.phase === "fallen") {
            var dauer = Math.max(traj.t_landung - tApex, 1e-9);
            frac = 0.5 + 0.5 * Math.min((p.t - tApex) / dauer, 1.0);
        } else {
            frac = 0.5 * Math.min(p.t / tApex, 1.0);
        }
        var x = X0 + frac * HORIZ_RANGE;
        var y = Y_BODEN - (p.h / hMaxSkala) * (Y_BODEN - Y_TOP);
        return [x, y];
    }

    function zeichnen() {
        if (!ctx) return;
        groesseAnpassen();
        ctx.setTransform(skala, 0, 0, skala, 0, 0);
        ctx.clearRect(0, 0, CANVAS_W, CANVAS_H);

        var hMax = traj ? traj.h_max : 10.0;
        var hMaxSkala = Math.max(hMax * 1.15, 1.0);
        hintergrund(hMaxSkala);

        if (traj && aktuellerIndex >= 0) {
            var punkte = traj.punkte;
            if (aktuellerIndex >= 1) {
                // Spur der bisherigen Flugbahn
                ctx.beginPath();
                for (var i = 0; i <= aktuellerIndex; i++) {
                    var pos = position(punkte[i], hMaxSkala);
                    if (i === 0) ctx.moveTo(pos[0], pos[1]);
                    else ctx.lineTo(pos[0], pos[1]);
                }
                ctx.strokeStyle = "#2563eb";
                ctx.lineWidth = 2;
                ctx.setLineDash([]);
                ctx.stroke();
            }
            var p = punkte[aktuellerIndex];
            var pp = position(p, hMaxSkala);
            rakete(pp[0], pp[1], p.phase === "brennen");
        } else {
            rakete(X0, Y_BODEN, false);
        }
    }

    function hintergrund(hMaxSkala) {
        var w = CANVAS_W, h = CANVAS_H;
        ctx.fillStyle = "#e0f2fe";
        ctx.fillRect(0, 0, w, h);
        ctx.fillStyle = "#bbf7d0";
        ctx.fillRect(0, Y_BODEN, w, h - Y_BODEN);
        ctx.strokeStyle = "#166534";
        ctx.lineWidth = 2;
        ctx.setLineDash([]);
        ctx.beginPath();
        ctx.moveTo(0, Y_BODEN); ctx.lineTo(w, Y_BODEN);
        ctx.moveTo(X0, Y_BODEN - 5); ctx.lineTo(X0, Y_BODEN + 5);
        ctx.stroke();

        // Schrift bleibt auf schmalen Bildschirmen lesbar (mindestens ca. 9,5 CSS-Pixel)
        var schriftPx = Math.max(10, 9.5 / (cssBreite / CANVAS_W));
        ctx.font = schriftPx + "px system-ui, \"Segoe UI\", Roboto, Helvetica, Arial, sans-serif";
        ctx.textBaseline = "middle";
        ctx.textAlign = "left";
        for (var i = 0; i < 5; i++) {
            var frac = i / 4.0;
            var hy = Y_BODEN - frac * (Y_BODEN - Y_TOP);
            ctx.strokeStyle = "#cbd5e1";
            ctx.lineWidth = 1;
            ctx.setLineDash([3, 3]);
            ctx.beginPath();
            ctx.moveTo(0, hy); ctx.lineTo(w, hy);
            ctx.stroke();
            ctx.setLineDash([]);
            ctx.fillStyle = "#64748b";
            ctx.fillText(Fmt.fest(frac * hMaxSkala, 1) + " m", 6, hy - 8);
        }
    }

    function polygon(punkte) {
        ctx.beginPath();
        ctx.moveTo(punkte[0], punkte[1]);
        for (var i = 2; i < punkte.length; i += 2) ctx.lineTo(punkte[i], punkte[i + 1]);
        ctx.closePath();
    }

    function rakete(x, boden, brennt) {
        var w = 12, hRumpf = 16, hSpitze = 10;
        var rumpfOben = boden - hRumpf;
        var dunkel = "#374151";
        ctx.lineWidth = 1;
        ctx.setLineDash([]);

        if (brennt) {
            ctx.fillStyle = "#f59e0b";
            polygon([x - w / 3, boden, x + w / 3, boden, x, boden + 14]);
            ctx.fill();
        }
        ctx.fillStyle = dunkel;
        polygon([x - w / 2, boden, x - w / 2 - 6, boden + 7, x - w / 2, boden - 6]);
        ctx.fill();
        polygon([x + w / 2, boden, x + w / 2 + 6, boden + 7, x + w / 2, boden - 6]);
        ctx.fill();
        ctx.fillStyle = "#d1d5db";
        ctx.fillRect(x - w / 2, rumpfOben, w, hRumpf);
        ctx.strokeStyle = dunkel;
        ctx.strokeRect(x - w / 2, rumpfOben, w, hRumpf);
        polygon([x - w / 2, rumpfOben, x + w / 2, rumpfOben, x, rumpfOben - hSpitze]);
        ctx.fillStyle = "#ef4444";
        ctx.fill();
        ctx.strokeStyle = dunkel;
        ctx.stroke();
    }

    // ------------------------------------------------------------------
    function init() {
        duesenBox = document.getElementById("duesenBox");
        tempoSlider = document.getElementById("tempo");
        tempoLabel = document.getElementById("tempoLabel");
        startBtn = document.getElementById("btnStart");
        pauseBtn = document.getElementById("btnPause");
        resetBtn = document.getElementById("btnReset");
        fortschritt = document.getElementById("animFortschritt");
        statusEl = document.getElementById("animStatus");
        canvas = document.getElementById("animCanvas");
        zeitSlider = document.getElementById("zeitSlider");
        zeitL = document.getElementById("kpZeit");
        hoeheL = document.getElementById("kpHoehe");
        geschwL = document.getElementById("kpGeschw");
        druckL = document.getElementById("kpDruck");
        tempL = document.getElementById("kpTemp");
        schubL = document.getElementById("kpSchub");
        ctx = canvas.getContext("2d");

        tempoSlider.addEventListener("input", function () {
            tempoLabel.textContent = Fmt.fest(tempoSlider.value / 100.0, 2) + "x";
        });
        startBtn.addEventListener("click", startGeklickt);
        pauseBtn.addEventListener("click", pauseGeklickt);
        resetBtn.addEventListener("click", resetGeklickt);
        zeitSlider.addEventListener("input", zeitSliderBewegt);
        FR.Ui.beiGroessenaenderung(canvas, zeichnen);
        zeichnen();
    }

    FR.AnimationTab = { init: init, setErgebnis: setErgebnis, neuZeichnen: zeichnen };
})(globalThis.FR = globalThis.FR || {});
