/* Einfaches Liniendiagramm als Inline-SVG (Port von LineChartPanel.java).
 * Achsen, Markierung des Optimums und optionale Referenzlinie; die Breite folgt dem Container.
 */
(function (FR) {
    "use strict";

    var Fmt = FR.Fmt;

    var HOEHE = 230;
    var M_L = 55, M_R = 20, M_T = 28, M_B = 40;

    function esc(s) {
        return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }

    function zahl(x) {
        return Math.round(x * 100) / 100;
    }

    /** Text mit vertikal zentriertem Ankerpunkt; anker: "middle" oder "end". */
    function text(s, x, y, anker, klasse, extra) {
        return "<text class=\"" + klasse + "\" x=\"" + zahl(x) + "\" y=\"" + zahl(y) + "\" dy=\"0.35em\" text-anchor=\""
            + anker + "\"" + (extra || "") + ">" + esc(s) + "</text>";
    }

    /** Erzeugt das SVG fuer die Breite w. d: {xs, ys, titel, xLabel, yLabel, highlight, yRef, yRefLabel}. */
    function svgErzeugen(d, w) {
        var h = HOEHE;
        var plotW = w - M_L - M_R;
        var plotH = h - M_T - M_B;
        var teile = [];
        teile.push("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"" + w + "\" height=\"" + h + "\" viewBox=\"0 0 "
            + w + " " + h + "\" role=\"img\" aria-label=\"" + esc(d.titel) + "\">");

        if (!d.xs || d.xs.length === 0 || d.ys.length === 0) {
            teile.push(text("Keine Daten", w / 2, h / 2, "middle", "c-text"));
            teile.push("</svg>");
            return teile.join("");
        }

        var xMin = Infinity, xMax = -Infinity, yMin = Infinity, yMax = -Infinity, i;
        for (i = 0; i < d.xs.length; i++) { xMin = Math.min(xMin, d.xs[i]); xMax = Math.max(xMax, d.xs[i]); }
        for (i = 0; i < d.ys.length; i++) { yMin = Math.min(yMin, d.ys[i]); yMax = Math.max(yMax, d.ys[i]); }
        if (d.yRef !== null && d.yRef !== undefined) {
            yMin = Math.min(yMin, d.yRef);
            yMax = Math.max(yMax, d.yRef);
        }
        if (xMin === xMax) xMax = xMin + 1.0;
        if (yMin === yMax) yMax = yMin + 1.0;
        var pad = (yMax - yMin) * 0.12;
        // Die Achse enthaelt immer die 0. Sind alle Werte >= 0 (Hoehe, Sicherheitsfaktor), liegt sie genau
        // auf 0 und das Polster gibt es nur nach oben (die Java-Vorlage rutschte hier knapp unter 0).
        yMin = yMin >= 0 ? 0.0 : yMin - pad;
        yMax = yMax + pad;

        function X(x) { return M_L + (x - xMin) / (xMax - xMin) * plotW; }
        function Y(y) { return M_T + plotH - (y - yMin) / (yMax - yMin) * plotH; }

        // Achsen (L-Form)
        teile.push("<path class=\"achse\" d=\"M" + M_L + " " + M_T + "V" + (M_T + plotH) + "H" + (M_L + plotW) + "\"/>");

        // Titel und Achsenbeschriftung
        teile.push(text(d.titel, w / 2, 12, "middle", "c-text titel"));
        teile.push(text(d.xLabel, M_L + plotW / 2, h - 8, "middle", "c-text klein"));
        var yMitte = M_T + plotH / 2;
        teile.push(text(d.yLabel, 14, yMitte, "middle", "c-text klein",
            " transform=\"rotate(-90 14 " + zahl(yMitte) + ")\""));

        // y-Ticks
        for (i = 0; i < 5; i++) {
            var yv = yMin + (yMax - yMin) * i / 4;
            var yy = Y(yv);
            teile.push("<path class=\"achse\" d=\"M" + (M_L - 4) + " " + zahl(yy) + "H" + M_L + "\"/>");
            teile.push(text(Fmt.g(yv, 2), M_L - 8, yy, "end", "c-text klein"));
        }

        // x-Ticks an jedem Datenpunkt
        for (i = 0; i < d.xs.length; i++) {
            var xx = X(d.xs[i]);
            teile.push("<path class=\"achse\" d=\"M" + zahl(xx) + " " + (M_T + plotH) + "V" + (M_T + plotH + 4) + "\"/>");
            teile.push(text(Fmt.g6(d.xs[i]), xx, M_T + plotH + 14, "middle", "c-text klein"));
        }

        // Referenzlinie (gestrichelt)
        if (d.yRef !== null && d.yRef !== undefined) {
            var yr = Y(d.yRef);
            teile.push("<path class=\"referenz\" d=\"M" + M_L + " " + zahl(yr) + "H" + (M_L + plotW) + "\"/>");
            if (d.yRefLabel) {
                teile.push(text(d.yRefLabel, M_L + plotW - 4, yr - 9, "end", "c-referenz klein"));
            }
        }

        // Datenlinie und Marker
        if (d.xs.length >= 2) {
            var pfad = "";
            for (i = 0; i < d.xs.length; i++) {
                pfad += (i === 0 ? "M" : "L") + zahl(X(d.xs[i])) + " " + zahl(Y(d.ys[i]));
            }
            teile.push("<path class=\"linie\" d=\"" + pfad + "\"/>");
        }
        for (i = 0; i < d.xs.length; i++) {
            var opt = i === d.highlight;
            teile.push("<circle class=\"" + (opt ? "punkt optimum" : "punkt") + "\" cx=\"" + zahl(X(d.xs[i]))
                + "\" cy=\"" + zahl(Y(d.ys[i])) + "\" r=\"" + (opt ? 5 : 3) + "\"/>");
        }
        teile.push("</svg>");
        return teile.join("");
    }

    /** Diagramm in einen Container zeichnen und bei Groessenaenderung neu zeichnen. */
    function erzeugen(container) {
        var daten = null;
        var letzteBreite = 0;

        function zeichnen() {
            if (!daten) return;
            var w = Math.max(280, Math.floor(container.clientWidth));
            letzteBreite = w;
            container.innerHTML = svgErzeugen(daten, w);
        }

        FR.Ui.beiGroessenaenderung(container, function () {
            if (daten && Math.max(280, Math.floor(container.clientWidth)) !== letzteBreite) zeichnen();
        });

        return {
            setDaten: function (xs, ys, titel, xLabel, yLabel, highlight, yRef, yRefLabel) {
                daten = {
                    xs: xs, ys: ys, titel: titel, xLabel: xLabel, yLabel: yLabel, highlight: highlight,
                    yRef: yRef, yRefLabel: yRefLabel
                };
                zeichnen();
            },
            neuZeichnen: zeichnen
        };
    }

    FR.Diagramm = { erzeugen: erzeugen, svgErzeugen: svgErzeugen };
})(globalThis.FR = globalThis.FR || {});
