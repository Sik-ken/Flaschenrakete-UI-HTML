/* Tab 2: Stoff- und Versuchsparameter (Port von ParameterTab.java).
 * Alle Werte stehen als Text in den Eingabefeldern (Anzeige mit g6); beim Berechnen
 * werden sie wieder eingelesen - wie in der Java- und der Python-Version.
 */
(function (FR) {
    "use strict";

    var Fmt = FR.Fmt;
    var el = FR.Ui.el;

    // [Attribut, Beschriftung, Einheit] - Reihenfolge = Anzeigereihenfolge (auch fuer die Pruefung beim Berechnen)
    var GRUPPEN = [
        {
            titel: "Brennstoffdaten", einklappbar: true, felder: [
                ["M_B", "Molmasse Brennstoff M_B", "kg/mol"],
                ["RHO_B", "Dichte flüssig RHO_B", "kg/m^3"],
                ["H_U", "unterer Heizwert H_U", "J/kg"],
                ["N_O2", "Sauerstoffbedarf N_O2", "mol/mol"],
                ["N_PROD", "gasförmige Produkte N_PROD", "mol/mol"],
                ["S_L", "lam. Brenngeschw. S_L (bei T_REF_SL)", "m/s"],
                ["T_REF_SL", "Referenztemperatur S_L T_REF_SL", "K"],
                ["N_SL", "Temperaturexponent S_L N_SL", "-"],
                ["SIGMA_293", "Expansionsverh. bei 293,15 K SIGMA_293", "-"],
                ["SIGMA_SLOPE", "Steigung Expansionsverh. SIGMA_SLOPE", "1/K"],
                ["T_AD", "isochore Flammentemp. T_AD", "K"],
                ["P_ISO_EXT", "isochorer Grenzdruck P_ISO_EXT", "Pa"]
            ]
        },
        {
            titel: "Luft und Umgebung", einklappbar: true, felder: [
                ["M_L", "Molmasse Luft M_L", "kg/mol"],
                ["Y_O2", "Sauerstoffanteil Luft Y_O2", "-"],
                ["R_UNIV", "universelle Gaskonstante R_UNIV", "J/(mol K)"],
                ["R_S", "spez. Gaskonstante R_S", "J/(kg K)"],
                ["KAPPA", "Isentropenexp. heiß KAPPA", "-"],
                ["KAPPA_U", "Isentropenexp. kalt KAPPA_U", "-"],
                ["T_0", "Umgebungstemperatur T_0", "K  (aus Umgebungstemperatur, Tab Start)"],
                ["P_0", "Umgebungsdruck P_0", "Pa"],
                ["RHO_L", "Luftdichte RHO_L", "kg/m^3"],
                ["G", "Erdbeschleunigung G", "m/s^2"]
            ]
        },
        {
            titel: "Modellparameter", einklappbar: true, felder: [
                ["CHI", "Flammenfaltungsfaktor CHI", "-"],
                ["C_D_HOLE", "Durchflusszahl Bohrung C_D_HOLE", "-"],
                ["H_WALL", "Wandwärmeübergang H_WALL", "W/(m^2 K)"],
                ["T_WALL", "Wandtemperatur T_WALL", "K"],
                ["ETA_C", "Verbrennungswirkungsgrad ETA_C", "-"]
            ]
        },
        {
            titel: "Numerik", felder: [
                ["DT", "Zeitschritt DT", "s"],
                ["T_MAX", "Abbruchzeit T_MAX", "s"]
            ]
        }
    ];

    var ALLE_ATTRS = [];
    GRUPPEN.forEach(function (g) {
        g.felder.forEach(function (f) { ALLE_ATTRS.push(f[0]); });
    });

    var felder = {};          // Attribut -> <input>
    var gruppeVonFeld = {};   // Attribut -> <details> (nur bei einklappbaren Gruppen)
    var duesenListe = null;   // <input> mit der Duesenliste
    var chiListe = null;      // <input> mit den chi-Werten
    var beimZuruecksetzen = function () { };

    function feld(attr, beschriftung, einheit) {
        var id = "p_" + attr;
        // kein inputmode="decimal": Werte wie 3.045e+07 brauchen auf dem Handy die normale Tastatur
        var eingabe = el("input", {
            id: id, type: "text", autocomplete: "off", autocapitalize: "off", spellcheck: "false",
            "aria-label": beschriftung
        });
        if (attr === "T_0") {          // kommt aus der Umgebungstemperatur im Tab Start
            eingabe.readOnly = true;
        }
        felder[attr] = eingabe;
        return el("div", { class: "zeile" },
            el("label", { "for": id }, beschriftung), eingabe, el("span", { class: "einheit" }, einheit));
    }

    function init(container) {
        GRUPPEN.forEach(function (g) {
            var zeilen = el("div", { class: "zeilen" });
            g.felder.forEach(function (f) { zeilen.appendChild(feld(f[0], f[1], f[2])); });
            if (g.einklappbar) {
                // Stoff- und Modellwerte aendert man selten: Block ist zugeklappt, ein Klick auf die Ueberschrift oeffnet ihn
                var details = el("details", { class: "gruppe einklapp" },
                    el("summary", null,
                        el("span", { class: "titel" }, g.titel),
                        el("span", { class: "anzahl" }, g.felder.length + " Werte")),
                    zeilen);
                g.felder.forEach(function (f) { gruppeVonFeld[f[0]] = details; });
                container.appendChild(details);
            } else {
                container.appendChild(el("fieldset", { class: "gruppe" }, el("legend", null, g.titel), zeilen));
            }
        });

        duesenListe = el("input", {
            id: "p_duesen", type: "text", autocomplete: "off", spellcheck: "false", class: "breit"
        });
        chiListe = el("input", {
            id: "p_chi", type: "text", autocomplete: "off", spellcheck: "false", class: "breit"
        });
        container.appendChild(el("fieldset", { class: "gruppe" },
            el("legend", null, "Düsenstudie und Kalibrierung"),
            el("div", { class: "listen" },
                el("label", { "for": "p_duesen" }, "Zu testende Düsendurchmesser [mm], mit ';' getrennt (z. B. 4; 5; 6,5; 8):"),
                duesenListe,
                el("label", { "for": "p_chi" }, "Chi-Kalibrierwerte [-], mit ';' getrennt:"),
                chiListe)));

        var reset = el("button", { type: "button", id: "btnStandard" }, "Auf Standardwerte zurücksetzen");
        reset.addEventListener("click", function () { beimZuruecksetzen(); });
        container.appendChild(el("div", { class: "knoepfe" }, reset));
    }

    /** Setzt ein Feld auf eine Zahl (Anzeige mit 6 signifikanten Stellen). */
    function setWert(attr, wert) {
        felder[attr].value = Fmt.g6(wert);
    }

    /** Aktueller Text eines Felds. */
    function text(attr) {
        return felder[attr].value;
    }

    /** Klappt den Block auf, in dem das Feld liegt (z. B. damit ein fehlerhafter Wert sichtbar wird). */
    function zeigeFeld(attr) {
        if (gruppeVonFeld[attr]) gruppeVonFeld[attr].open = true;
    }

    FR.ParameterTab = {
        ALLE_ATTRS: ALLE_ATTRS, init: init, setWert: setWert, text: text, zeigeFeld: zeigeFeld,
        get duesenListe() { return duesenListe; },
        get chiListe() { return chiListe; },
        setBeimZuruecksetzen: function (fn) { beimZuruecksetzen = fn; }
    };
})(globalThis.FR = globalThis.FR || {});
