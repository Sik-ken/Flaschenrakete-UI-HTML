/* Verdrahtung der Oberflaeche: Tabs, Design-Umschalter (Auto/Hell/Dunkel) und Datenfluss zwischen den Tabs
 * (Port von FlaschenraketeApp.java).
 */
(function (FR) {
    "use strict";

    // ------------------------------------------------------------------
    // Tabs (WAI-ARIA: tablist / tab / tabpanel, Pfeiltasten wechseln den Tab)
    // ------------------------------------------------------------------
    function tabsInit() {
        var tabs = Array.prototype.slice.call(document.querySelectorAll("[role=tab]"));

        function aktivieren(tab, fokus) {
            tabs.forEach(function (t) {
                var aktiv = t === tab;
                t.setAttribute("aria-selected", aktiv ? "true" : "false");
                t.tabIndex = aktiv ? 0 : -1;
                document.getElementById(t.getAttribute("aria-controls")).hidden = !aktiv;
            });
            if (fokus) tab.focus();
            if (tab.id === "t-animation") FR.AnimationTab.neuZeichnen();
        }

        tabs.forEach(function (tab, i) {
            tab.addEventListener("click", function () { aktivieren(tab, false); });
            tab.addEventListener("keydown", function (e) {
                var ziel = null;
                if (e.key === "ArrowRight") ziel = tabs[(i + 1) % tabs.length];
                else if (e.key === "ArrowLeft") ziel = tabs[(i - 1 + tabs.length) % tabs.length];
                else if (e.key === "Home") ziel = tabs[0];
                else if (e.key === "End") ziel = tabs[tabs.length - 1];
                if (ziel) {
                    e.preventDefault();
                    aktivieren(ziel, true);
                }
            });
        });
    }

    // ------------------------------------------------------------------
    // Design: Auto (Systemeinstellung) -> Hell -> Dunkel
    // ------------------------------------------------------------------
    var THEMEN = ["auto", "hell", "dunkel"];
    var THEMA_TEXT = { auto: "Design: Auto", hell: "Design: Hell", dunkel: "Design: Dunkel" };
    var SCHLUESSEL = "flaschenrakete-design";

    function themaLesen() {
        try {
            var wert = window.localStorage.getItem(SCHLUESSEL);
            if (THEMEN.indexOf(wert) >= 0) return wert;
        } catch (e) { /* Speicher nicht verfuegbar: Auto */ }
        return "auto";
    }

    function themaSetzen(thema, speichern) {
        var root = document.documentElement;
        if (thema === "auto") root.removeAttribute("data-theme");
        else root.setAttribute("data-theme", thema);
        document.getElementById("themeBtn").textContent = THEMA_TEXT[thema];
        if (speichern) {
            try { window.localStorage.setItem(SCHLUESSEL, thema); } catch (e) { /* egal */ }
        }
    }

    function themeInit() {
        var aktuell = themaLesen();
        themaSetzen(aktuell, false);
        document.getElementById("themeBtn").addEventListener("click", function () {
            aktuell = THEMEN[(THEMEN.indexOf(aktuell) + 1) % THEMEN.length];
            themaSetzen(aktuell, true);
        });
    }

    // ------------------------------------------------------------------
    function start() {
        FR.ParameterTab.init(document.getElementById("parameterInhalt"));
        FR.StartTab.init();
        FR.BerechnungTab.init();
        FR.AnimationTab.init();
        FR.Hilfe.init();
        FR.BerechnungTab.setBeiErgebnis(FR.AnimationTab.setErgebnis);
        tabsInit();
        themeInit();
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
    else start();
})(globalThis.FR = globalThis.FR || {});
