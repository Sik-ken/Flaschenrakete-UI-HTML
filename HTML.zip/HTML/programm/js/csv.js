/* CSV-Export der Duesenstudie (Port von CsvExport.java): Semikolon-getrennt,
 * Punkt als Dezimaltrenner, Zeilenende \r\n (wie das Python-Original).
 */
(function (FR) {
    "use strict";

    var Fmt = FR.Fmt;

    var KOPF = "d_mm;p_max_bar;F_max_N;impuls_Ns;v_bo;hoehe_brenn_m;hoehe_frei_m;hoehe_m;sicherheitsfaktor";

    function zeilen(erg) {
        var sb = KOPF + "\r\n";
        for (var i = 0; i < erg.length; i++) {
            var e = erg[i];
            sb += [
                Fmt.repr(e.d_mm), Fmt.repr(e.p_max_bar), Fmt.repr(e.F_max_N), Fmt.repr(e.impuls_Ns),
                Fmt.repr(e.v_bo), Fmt.repr(e.hoehe_brenn_m), Fmt.repr(e.hoehe_frei_m),
                Fmt.repr(e.hoehe_m), Fmt.repr(e.sicherheitsfaktor)
            ].join(";") + "\r\n";
        }
        return sb;
    }

    /** Standard-Dateiname: duesenstudie_<brennstoff kleingeschrieben>.csv */
    function standardName(brennstoff) {
        return "duesenstudie_" + String(brennstoff).toLowerCase() + ".csv";
    }

    FR.Csv = { KOPF: KOPF, zeilen: zeilen, standardName: standardName };
})(globalThis.FR = globalThis.FR || {});
