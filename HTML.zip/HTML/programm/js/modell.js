/* Berechnungsmodell der Flaschenrakete (Port von Berechnungsmodell.java bzw.
 * berechnungsmodell_flaschenrakete_v2.py).
 *
 * Nulldimensionales Kammermodell der ventilierten Deflagration einer PET-Flasche
 * mit Alkohol-Luft-Gemisch, mit anschliessender Schub- und Flugrechnung.
 *
 * Abschnitte wie im Original: 2 Stoechiometrie, 3 isochore Druckobergrenze,
 * 4 instationaeres Kammermodell, 5 Brennschluss, 6 Flugmechanik,
 * 7 Duesenstudie und Kalibrierung. Die Reihenfolge der Rechenschritte im
 * Kammermodell ist absichtlich identisch zum Original (auch das Aufsummieren
 * von t += DT), damit die Schrittzahlen exakt uebereinstimmen.
 *
 * Temperaturabhaengigkeit: Die Umgebungstemperatur ist par.T_0 (= T_amb, einzige Quelle).
 * sigma(par) und sL(par) berechnen daraus das Expansionsverhaeltnis (linear) und die laminare
 * Brenngeschwindigkeit (Potenzansatz). S_L wird nur mit der Umgebungstemperatur skaliert, nicht
 * mit der lokalen Temperatur des verdichteten Frischgases; so bleibt die Kalibrierung von CHI
 * und H_WALL gueltig. Zulaessig sind 288,15 bis 308,15 K (15 bis 35 C), sonst Fehler (kein
 * stilles Begrenzen).
 *
 * Gueltigkeit: Das Modell setzt phi = 1 voraus. Bei Isopropanol begrenzt der Saettigungsdampfdruck das
 * erreichbare phi (phi_max: 15 C 0,73; 20 C 0,98; 30 C 1,75); am belastbarsten ist das Modell im
 * Kernbereich um 18 bis 26 C, die Randbereiche sind Extrapolation.
 * TODO (spaetere Ausbaustufe, bewusst nicht implementiert): phi(T) = min(phi_dosiert, phi_sat(T)).
 */
(function (FR) {
    "use strict";

    // =====================================================================
    // UMGEBUNGSTEMPERATUR: GUELTIGKEITSBEREICH UND TEMPERATURABHAENGIGE STOFFWERTE
    // =====================================================================
    var T_AMB_MIN_K = 288.15;      // 15 C
    var T_AMB_MAX_K = 308.15;      // 35 C
    var T_AMB_TOLERANZ_K = 1e-6;   // Gleitkomma-Rauschen bei 15 C / 35 C (273,15 + 15 ist nicht exakt 288,15)

    /** Wirft einen Fehler, wenn T_0 ausserhalb von 288,15 bis 308,15 K (15 bis 35 °C) liegt. */
    function pruefeUmgebungstemperatur(par) {
        var T = par.T_0;
        if (!(T_AMB_MIN_K - T_AMB_TOLERANZ_K <= T && T <= T_AMB_MAX_K + T_AMB_TOLERANZ_K)) {   // auch bei NaN
            throw new Error("Umgebungstemperatur T_0 = " + FR.Fmt.fest(T, 2) + " K (" + FR.Fmt.fest(T - 273.15, 2)
                + " °C) liegt außerhalb des Gültigkeitsbereichs des Modells von " + FR.Fmt.fest(T_AMB_MIN_K, 2)
                + " bis " + FR.Fmt.fest(T_AMB_MAX_K, 2) + " K (15 bis 35 °C). σ(T) und S_L(T) sind nur dort belegt "
                + "bzw. extrapoliert.");
        }
    }

    /** Expansionsverhaeltnis rho_u/rho_b bei der Umgebungstemperatur T_0 (linear). */
    function sigma(par) {
        pruefeUmgebungstemperatur(par);
        return par.SIGMA_293 + par.SIGMA_SLOPE * (par.T_0 - 293.15);
    }

    /** Laminare Brenngeschwindigkeit bei der Umgebungstemperatur T_0 (Potenzansatz); S_L gilt bei T_REF_SL. */
    function sL(par) {
        pruefeUmgebungstemperatur(par);
        return par.S_L * Math.pow(par.T_0 / par.T_REF_SL, par.N_SL);
    }

    // =====================================================================
    // 2  STOECHIOMETRIE UND DOSIERUNG
    // =====================================================================
    function stoechiometrie(par) {
        pruefeUmgebungstemperatur(par);
        var n_L  = par.N_O2 / par.Y_O2;                 // mol Luft je mol Brennstoff
        var phi  = 1.0 / (1.0 + n_L);                   // Volumenanteil Brennstoff
        var L_st = n_L * par.M_L / par.M_B;             // kg Luft je kg Brennstoff
        var H_G  = par.H_U / (1.0 + L_st);              // Gemischheizwert J/kg
        var V_m  = par.R_UNIV * par.T_0 / par.P_0;      // molares Volumen, m^3/mol
        var m_B  = phi / V_m * par.M_B;                 // kg Brennstoff je m^3 Gemisch
        return {
            n_L: n_L, phi: phi, L_st: L_st, H_G: H_G, V_m: V_m, m_B_pro_m3: m_B,
            m_B_flasche: m_B * par.V_FL, V_B_flasche: m_B * par.V_FL / par.RHO_B
        };
    }

    // =====================================================================
    // 3  ISOCHORE DRUCKOBERGRENZE
    // =====================================================================
    /** Isochore Flammentemperatur aus der Energiebilanz (nur Plausibilitaetspruefung). */
    function isochoreFlammentemperatur(par, H_G) {
        return par.T_0 + H_G * par.ETA_C / par.cv();
    }

    function grenzdruck(par, st) {
        pruefeUmgebungstemperatur(par);
        var n1 = 1.0 + st.n_L;
        var n2 = par.N_PROD + st.n_L * (1.0 - par.Y_O2);
        var pModell = par.P_0 * (n2 / n1) * (par.T_AD / par.T_0);
        var pExtern = par.P_ISO_EXT;
        var pAusl = Math.max(pModell, pExtern);
        var abweichung = pExtern > 0.0 ? (pModell / pExtern - 1.0) * 100.0 : NaN;
        var tBilanz = isochoreFlammentemperatur(par, st.H_G);
        return {
            n1: n1, n2: n2, verhaeltnis: n2 / n1, T_ad_extern: par.T_AD, T_ad_bilanz: tBilanz,
            p_modell: pModell, p_extern: pExtern, p_ausl: pAusl, abweichung_pct: abweichung,
            sicherheitsfaktor: pAusl > 0.0 ? par.P_BURST / pAusl : NaN,
            p_zulaessig: par.P_BURST / par.S_MIN
        };
    }

    // =====================================================================
    // 4  INSTATIONAERES KAMMERMODELL
    // =====================================================================
    /** Ausflussfunktion Gamma nach Saint-Venant und Wantzel; kritisch = Druckverhaeltnis ueberkritisch. */
    function ausflussfunktion(par, pInnen, pAussen) {
        var k = par.KAPPA;
        var prKrit = Math.pow((k + 1.0) / 2.0, k / (k - 1.0));
        if (pInnen / pAussen >= prKrit) {                                   // ueberkritisch
            return {
                gamma: Math.sqrt(k) * Math.pow(2.0 / (k + 1.0), (k + 1.0) / (2.0 * (k - 1.0))),
                kritisch: true
            };
        }
        var pr = pAussen / pInnen;                                          // unterkritisch
        var term = Math.pow(pr, 2.0 / k) - Math.pow(pr, (k + 1.0) / k);
        return { gamma: Math.sqrt(2.0 * k / (k - 1.0) * Math.max(term, 0.0)), kritisch: false };
    }

    /** Zeitschrittintegration fuer einen Bohrungsdurchmesser in Metern (chiWert == null: par.CHI). */
    function kammermodell(par, dBohrung, chiWert, verlauf) {
        pruefeUmgebungstemperatur(par);
        var chi = (chiWert === null || chiWert === undefined) ? par.CHI : chiWert;
        // Laminare Brenngeschwindigkeit bei der Umgebungstemperatur (einmal, nicht je Zeitschritt):
        // bewusst NICHT mit der lokalen Temperatur des verdichteten Frischgases skaliert.
        var S_L_amb = sL(par);

        var st = stoechiometrie(par);
        var H_G = st.H_G;

        var A_quer = Math.PI / 4.0 * par.D_FL * par.D_FL;        // Flaschenquerschnitt
        var A_hole = Math.PI / 4.0 * dBohrung * dBohrung;        // Bohrungsflaeche
        // Waermeuebertragende Innenflaeche aus der gemessenen Innenhoehe
        var A_wall = Math.PI * par.D_FL * par.L_FL + 2 * A_quer;

        var rho_0 = par.P_0 / (par.R_S * par.T_0);               // Anfangsdichte des Gemisches
        var m = rho_0 * par.V_FL;                                // Masse in der Flasche
        var T = par.T_0;
        var p = par.P_0;
        var mFrisch = m;                                         // noch unverbrannte Masse
        var mVerbranntGesamt = 0.0;

        var t = 0.0;
        var schritt = 0;
        var impuls = 0.0;
        var pMax = par.P_0;
        var FMax = 0.0;
        var verlaufsdaten = [];

        // Hoehe/Geschwindigkeit waehrend der Brennphase, mit Luftwiderstand
        var A_stirn = A_quer;
        var kLuft = 0.5 * par.RHO_L * par.C_D_AIR * A_stirn / par.M_FL;
        var hBrenn = 0.0;
        var vBrenn = 0.0;

        var cv = par.cv();
        var cp = par.cp();

        while (t < par.T_MAX) {
            // Isentrope Verdichtung des kalten Frischgases (KAPPA_U)
            var rho_u = rho_0 * Math.pow(p / par.P_0, 1.0 / par.KAPPA_U);
            var rateVerbr = rho_u * chi * S_L_amb * A_quer;      // kg/s
            rateVerbr = Math.min(rateVerbr, mFrisch > 0 ? mFrisch / par.DT : 0.0);

            var af = ausflussfunktion(par, p, par.P_0);
            var gamma = af.gamma;
            var kritisch = af.kritisch;
            var rateAus = par.C_D_HOLE * A_hole * p * gamma / Math.sqrt(par.R_S * T);
            rateAus = Math.min(rateAus, m / par.DT);             // nie mehr als vorhanden

            var qWand = par.H_WALL * A_wall * (T - par.T_WALL);

            var dU = (rateVerbr * H_G * par.ETA_C
                      - rateAus * cp * T
                      - qWand) * par.DT;
            var dm = -rateAus * par.DT;

            var uNeu = m * cv * T + dU;
            var mAlt = m;
            var mNeu = m + dm;
            if (mNeu <= 1e-9) {
                break;
            }
            T = uNeu / (mNeu * cv);
            T = Math.max(T, par.T_0);
            m = mNeu;
            p = m * par.R_S * T / par.V_FL;
            p = Math.max(p, par.P_0);

            // ideal durchmischte Kammer: Frisch- und Abgas stroemen anteilig aus
            var anteilFrisch = mAlt > 0.0 ? mFrisch / mAlt : 0.0;
            mFrisch = Math.max(mFrisch - rateVerbr * par.DT + dm * anteilFrisch, 0.0);
            mVerbranntGesamt += rateVerbr * par.DT;

            // Schub aus Impulssatz (bei ueberkritischem Druckverhaeltnis Schallgeschwindigkeit)
            var vAus;
            var pHals;
            if (kritisch) {
                var THals = T * 2.0 / (par.KAPPA + 1.0);
                vAus = Math.sqrt(par.KAPPA * par.R_S * THals);
                pHals = p * Math.pow(2.0 / (par.KAPPA + 1.0), par.KAPPA / (par.KAPPA - 1.0));
            } else {
                vAus = Math.sqrt(Math.max(2.0 * cp * T * (1.0 - Math.pow(par.P_0 / p,
                        (par.KAPPA - 1.0) / par.KAPPA)), 0.0));
                pHals = par.P_0;
            }
            var F = rateAus * vAus + (pHals - par.P_0) * A_hole;

            impuls += F * par.DT;
            pMax = Math.max(pMax, p);
            FMax = Math.max(FMax, F);

            vBrenn += (F / par.M_FL - par.G - kLuft * vBrenn * Math.abs(vBrenn)) * par.DT;
            hBrenn = Math.max(hBrenn + vBrenn * par.DT, 0.0);

            if (verlauf && schritt % 20 === 0) {
                verlaufsdaten.push({ t_ms: t * 1e3, p_bar: p / 1e5, F: F, T: T, h: hBrenn, v: vBrenn });
            }

            schritt++;
            t += par.DT;
            if (mFrisch <= 1e-9 && p <= par.P_0 * 1.001) {
                break;
            }
        }

        return {
            d: dBohrung, p_max: pMax, F_max: FMax, impuls: impuls, t_ende: t,
            verlauf: verlaufsdaten, h_brenn: hBrenn, v_brenn: vBrenn
        };
    }

    // =====================================================================
    // 5  BRENNSCHLUSSGESCHWINDIGKEIT
    // =====================================================================
    /** Vereinfachte Brennschlussgeschwindigkeit ohne Luftwiderstand (nur Vergleichsgroesse). */
    function brennschluss(par, impuls, tBrenn) {
        var v = impuls / par.M_FL - par.G * tBrenn;
        return Math.max(v, 0.0);
    }

    // =====================================================================
    // 6  FLUGMECHANIK MIT LUFTWIDERSTAND
    // =====================================================================
    function grenzgeschwindigkeit(par) {
        var A_stirn = Math.PI / 4.0 * par.D_FL * par.D_FL;
        return Math.sqrt(2.0 * par.M_FL * par.G / (par.RHO_L * par.C_D_AIR * A_stirn));
    }

    /** Steighoehe bei quadratischem Luftwiderstand. */
    function steighoehe(par, vBo) {
        var vT = grenzgeschwindigkeit(par);
        if (vBo <= 0.0) {
            return 0.0;
        }
        return (vT * vT / (2.0 * par.G)) * Math.log(1.0 + vBo * vBo / (vT * vT));
    }

    function steighoeheOhneWiderstand(par, vBo) {
        return vBo * vBo / (2.0 * par.G);
    }

    /** Zeitaufgeloeste Flugbahn (Brennen, Steigen, Fallen) fuer die Animation. */
    function flugbahn(par, dBohrung, chi, dt) {
        if (chi === undefined) chi = null;
        if (dt === undefined) dt = 5e-3;
        var r = kammermodell(par, dBohrung, chi, true);
        var vBo = r.v_brenn;

        var punkte = [];
        for (var i = 0; i < r.verlauf.length; i++) {
            var vl = r.verlauf[i];
            punkte.push({
                t: vl.t_ms / 1e3, phase: "brennen", p: vl.p_bar * 1e5, T: vl.T, F: vl.F,
                h: vl.h, v: vl.v
            });
        }

        var vT = grenzgeschwindigkeit(par);
        var k = vT > 0.0 ? par.G / (vT * vT) : 0.0;

        var t = r.t_ende;
        var h = r.h_brenn;
        var v = vBo;
        var tApex = null;
        var tMax = t + 120.0;   // Sicherheitsgrenze gegen Endlosschleifen bei Extremwerten

        while (true) {
            var a = -par.G - k * v * Math.abs(v);
            v = v + a * dt;
            h = h + v * dt;
            t = t + dt;
            if (tApex === null && v < 0.0) {
                tApex = t;
            }
            var landung = h <= 0.0;
            if (landung) {
                h = 0.0;
            }
            punkte.push({
                t: t, phase: v < 0.0 ? "fallen" : "steigen", p: par.P_0, T: par.T_0, F: 0.0,
                h: h, v: v
            });
            if (landung || t > tMax) {
                break;
            }
        }

        var hMax = 0.0;
        for (var j = 0; j < punkte.length; j++) {
            hMax = Math.max(hMax, punkte[j].h);
        }
        return {
            punkte: punkte, h_brenn: r.h_brenn, v_bo: vBo, t_brenn: r.t_ende, t_apex: tApex,
            h_max: hMax, h_max_formel: r.h_brenn + steighoehe(par, vBo), t_landung: t,
            v_aufprall: Math.abs(v)
        };
    }

    // =====================================================================
    // 7  DUESENSTUDIE UND KALIBRIERUNG
    // =====================================================================
    /** Geschlossene Abschaetzung des kritischen Bohrungsdurchmessers (chi/tB == null: an par gekoppelt). */
    function kritischerDurchmesser(par, chiWert, tBWert) {
        pruefeUmgebungstemperatur(par);
        var chi = (chiWert === null || chiWert === undefined) ? par.CHI : chiWert;
        var tB = (tBWert === null || tBWert === undefined) ? par.T_AD : tBWert;
        var gammaKrit = ausflussfunktion(par, 10.0 * par.P_0, par.P_0).gamma;
        var nenner = par.C_D_HOLE * gammaKrit * Math.sqrt(par.R_S * tB);
        var zaehler = chi * sL(par) * (sigma(par) - 1.0);
        return par.D_FL * Math.sqrt(zaehler / nenner);
    }

    /** Kennwerte fuer einen Duesendurchmesser in mm, inkl. Aufschluesselung der Hoehe (chi == null: par.CHI). */
    function duese(par, dMm, chi) {
        var r = kammermodell(par, dMm / 1000.0, chi, false);
        var vBo = r.v_brenn;
        var hoeheBrenn = r.h_brenn;
        var hoeheFrei = steighoehe(par, vBo);
        return {
            d_mm: dMm, p_max_bar: r.p_max / 1e5, F_max_N: r.F_max, impuls_Ns: r.impuls, v_bo: vBo,
            hoehe_brenn_m: hoeheBrenn, hoehe_frei_m: hoeheFrei, hoehe_m: hoeheBrenn + hoeheFrei,
            sicherheitsfaktor: par.P_BURST / r.p_max
        };
    }

    /** Kennwerte je Duesendurchmesser (chi == null: par.CHI). */
    function duesenstudie(par, durchmesserMm, chi) {
        pruefeUmgebungstemperatur(par);
        var ergebnisse = [];
        for (var i = 0; i < durchmesserMm.length; i++) {
            ergebnisse.push(duese(par, durchmesserMm[i], chi));
        }
        return ergebnisse;
    }

    /** Duese mit der groessten Gesamthoehe (erste bei Gleichstand, wie Pythons max()). */
    function optimum(erg) {
        var best = erg[0];
        for (var i = 0; i < erg.length; i++) {
            if (erg[i].hoehe_m > best.hoehe_m) {
                best = erg[i];
            }
        }
        return best;
    }

    /** Kalibrierungszeile aus einer bereits gerechneten Duesenstudie mit diesem chi. */
    function kalibrierungAusStudie(par, chi, erg) {
        var best = optimum(erg);
        return {
            chi: chi, d_opt_mm: best.d_mm, hoehe_m: best.hoehe_m,
            d_krit_mm: kritischerDurchmesser(par, chi, null) * 1000.0
        };
    }

    /** Optimaler Durchmesser fuer einen Flammenfaltungsfaktor. */
    function kalibrierungFuerChi(par, chi, durchmesserMm) {
        return kalibrierungAusStudie(par, chi, duesenstudie(par, durchmesserMm, chi));
    }

    /** Optimaler Durchmesser je Flammenfaltungsfaktor. */
    function kalibrierung(par, chiWerte, durchmesserMm) {
        pruefeUmgebungstemperatur(par);
        var out = [];
        for (var i = 0; i < chiWerte.length; i++) {
            out.push(kalibrierungFuerChi(par, chiWerte[i], durchmesserMm));
        }
        return out;
    }

    FR.Modell = {
        T_AMB_MIN_K: T_AMB_MIN_K, T_AMB_MAX_K: T_AMB_MAX_K,
        pruefeUmgebungstemperatur: pruefeUmgebungstemperatur, sigma: sigma, sL: sL,
        stoechiometrie: stoechiometrie, isochoreFlammentemperatur: isochoreFlammentemperatur,
        grenzdruck: grenzdruck, ausflussfunktion: ausflussfunktion, kammermodell: kammermodell,
        brennschluss: brennschluss, grenzgeschwindigkeit: grenzgeschwindigkeit,
        steighoehe: steighoehe, steighoeheOhneWiderstand: steighoeheOhneWiderstand,
        flugbahn: flugbahn, kritischerDurchmesser: kritischerDurchmesser, duese: duese,
        duesenstudie: duesenstudie, optimum: optimum, kalibrierungAusStudie: kalibrierungAusStudie,
        kalibrierungFuerChi: kalibrierungFuerChi, kalibrierung: kalibrierung
    };
})(globalThis.FR = globalThis.FR || {});
