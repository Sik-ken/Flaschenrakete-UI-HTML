/* Tab 1: Brennstoff, Umgebungstemperatur, Flaschen-Preset und Flaschenparameter (Port von StartTab.java).
 * Enthaelt ausserdem die Logik, die alle Eingaben (auch die des Parameter-Tabs) zu einem
 * Parameter-Objekt zusammenfuehrt bzw. aus einem Parameter-Objekt befuellt.
 */
(function (FR) {
    "use strict";

    var Fmt = FR.Fmt;
    var Presets = FR.Presets;
    var Tab2 = FR.ParameterTab;
    var el = FR.Ui.el;

    var EIGENE_WERTE = "Eigene Werte";
    var TEMPERATUR_ERLAUBT = /^[0-9]*[.,]?[0-9]*$/;

    var brennstoffBox, flascheBox, umgebungFeld, umgebungListe, umgebungPfeil;
    var vFl, dFl, lFl, mFl, cdAir, pBurst, sMin, statusEl;
    var letzterTemperaturWert = "";

    /** Statusmeldung im Start-Tab. */
    function status(text) {
        statusEl.textContent = text;
    }

    // ------------------------------------------------------------------
    // Ereignisse
    // ------------------------------------------------------------------
    function beiBrennstoffGewaehlt() {
        var preset = Presets.FUEL_PRESETS[brennstoffBox.value];
        if (!preset) return;
        Presets.FUEL_ATTRS.forEach(function (attr) {
            Tab2.setWert(attr, preset[attr]);
        });
        // S_L ist der Referenzwert bei T_REF_SL; die Umrechnung auf die Umgebungstemperatur (und sigma(T))
        // macht das Modell. Hier werden nur T_0, T_WALL und RHO_L neu gesetzt.
        umgebungAufTab2Anwenden();
    }

    function umgebungAufTab2Anwenden() {
        var tC;
        try {
            tC = umgebungLesen();
        } catch (e) {
            return;      // ungueltige Zwischenzustaende beim Tippen werden ignoriert
        }
        var werte = Presets.umgebungswerte(tC);
        for (var name in werte) {
            Tab2.setWert(name, werte[name]);
        }
    }

    function beiFlaschenPresetGewaehlt() {
        var f = Presets.BOTTLE_PRESETS[flascheBox.value];
        if (!f) return;
        vFl.value = Fmt.g6(f.V_FL * 1e3);
        dFl.value = Fmt.g6(f.D_FL * 1e3);
        lFl.value = Fmt.g6(f.L_FL * 1e3);
        mFl.value = Fmt.g6(f.M_FL * 1e3);
    }

    function beiFlaschenfeldGeaendert() {
        if (flascheBox.value !== EIGENE_WERTE) {
            flascheBox.value = EIGENE_WERTE;
        }
    }

    // ------------------------------------------------------------------
    // Umgebungstemperatur: Eingabefilter und Auswahlliste
    // ------------------------------------------------------------------
    /** Nur Ziffern und ein Dezimaltrenner: kein Minuszeichen, keine negativen Werte. */
    function beiTemperaturEingabe() {
        var neu = umgebungFeld.value;
        if (!TEMPERATUR_ERLAUBT.test(neu)) {
            var caret = umgebungFeld.selectionStart - (neu.length - letzterTemperaturWert.length);
            umgebungFeld.value = letzterTemperaturWert;
            caret = Math.max(0, Math.min(caret, letzterTemperaturWert.length));
            umgebungFeld.setSelectionRange(caret, caret);
            return;
        }
        letzterTemperaturWert = neu;
        umgebungAufTab2Anwenden();
    }

    /** Setzt das Temperaturfeld programmatisch (am Eingabefilter vorbei). */
    function umgebungSetzen(text) {
        umgebungFeld.value = text;
        letzterTemperaturWert = text;
    }

    function listeUmschalten(sichtbar) {
        umgebungListe.hidden = !sichtbar;
        umgebungPfeil.setAttribute("aria-expanded", sichtbar ? "true" : "false");
    }

    function temperaturListeAufbauen() {
        for (var t = Presets.T_UMGEBUNG_MIN_C; t <= Presets.T_UMGEBUNG_MAX_C; t += 5) {
            var text = Fmt.g6(t);
            var eintrag = el("li", { role: "option", tabindex: "-1" }, text);
            eintrag.addEventListener("mousedown", function (e) { e.preventDefault(); });   // Fokus im Feld lassen
            eintrag.addEventListener("click", (function (wert) {
                return function () {
                    umgebungSetzen(wert);
                    listeUmschalten(false);
                    umgebungAufTab2Anwenden();
                };
            })(text));
            umgebungListe.appendChild(eintrag);
        }
        umgebungPfeil.addEventListener("click", function () {
            listeUmschalten(umgebungListe.hidden);
            umgebungFeld.focus();
        });
        umgebungFeld.addEventListener("keydown", function (e) {
            if (e.key === "ArrowDown" && umgebungListe.hidden) {
                e.preventDefault();
                listeUmschalten(true);
            } else if (e.key === "Escape") {
                listeUmschalten(false);
            }
        });
        document.addEventListener("click", function (e) {
            if (!umgebungListe.hidden && !umgebungListe.parentNode.contains(e.target)) {
                listeUmschalten(false);
            }
        });
    }

    // ------------------------------------------------------------------
    // Standardwerte
    // ------------------------------------------------------------------
    function tab2Zuruecksetzen() {
        var defaults = new FR.Parameter();
        var preset = Presets.FUEL_PRESETS[brennstoffBox.value] || Presets.FUEL_PRESETS["Isopropanol"];
        Presets.brennstoffAnwenden(defaults, preset);
        Tab2.ALLE_ATTRS.forEach(function (attr) {
            Tab2.setWert(attr, defaults[attr]);
        });
        var basis = new FR.Parameter();
        Tab2.duesenListe.value = Fmt.joinList(basis.duesendurchmesser_mm);
        Tab2.chiListe.value = Fmt.joinList(basis.chi_kalibrierwerte);
        // C_D_AIR, P_BURST und S_MIN sind nicht Teil der Flaschen-Presets (unabhaengig von der Geometrie)
        cdAir.value = Fmt.g6(basis.C_D_AIR);
        pBurst.value = Fmt.g6(basis.P_BURST / 1e5);
        sMin.value = Fmt.g6(basis.S_MIN);
        umgebungSetzen(Fmt.g6(Presets.T_UMGEBUNG_STANDARD_C));
        umgebungAufTab2Anwenden();
    }

    // ------------------------------------------------------------------
    // Parameter einsammeln / anwenden
    // ------------------------------------------------------------------
    /** Umgebungstemperatur in Grad Celsius, erlaubt sind nur 0 bis 60 C. */
    function umgebungLesen() {
        var text = umgebungFeld.value;
        var tC = Fmt.parse(text, "Umgebungstemperatur");
        if (!(Presets.T_UMGEBUNG_MIN_C <= tC && tC <= Presets.T_UMGEBUNG_MAX_C)) {
            throw new Error("Die Umgebungstemperatur muss zwischen " + Fmt.g6(Presets.T_UMGEBUNG_MIN_C)
                + " und " + Fmt.g6(Presets.T_UMGEBUNG_MAX_C) + " Grad Celsius liegen (eingegeben: '"
                + text.trim() + "').");
        }
        return tC;
    }

    /** Liest alle Eingaben und baut den Parametersatz. Wirft Error bei ungueltigen Werten. */
    function parameterSammeln() {
        var par = new FR.Parameter();
        par.brennstoff = brennstoffBox.value;
        par.V_FL = Fmt.parse(vFl.value, "Flaschenvolumen V_FL") * 1e-3;
        par.D_FL = Fmt.parse(dFl.value, "Durchmesser D_FL") * 1e-3;
        par.L_FL = Fmt.parse(lFl.value, "Innenhöhe L_FL") * 1e-3;
        par.M_FL = Fmt.parse(mFl.value, "Leermasse M_FL") * 1e-3;
        par.C_D_AIR = Fmt.parse(cdAir.value, "Widerstandsbeiwert C_D_AIR");
        par.P_BURST = Fmt.parse(pBurst.value, "Mindestberstdruck P_BURST") * 1e5;
        par.S_MIN = Fmt.parse(sMin.value, "Sicherheitsfaktor S_MIN");
        Tab2.ALLE_ATTRS.forEach(function (attr) {
            try {
                par[attr] = Fmt.parse(Tab2.text(attr), attr);
            } catch (e) {
                Tab2.zeigeFeld(attr);      // zugeklappten Block oeffnen, damit das Feld auffindbar ist
                throw e;
            }
        });
        // Umgebungstemperatur: Eingabe in Grad Celsius, Modell rechnet in Kelvin
        par.T_0 = Presets.celsiusZuKelvin(umgebungLesen());
        par.duesendurchmesser_mm = Fmt.parseList(Tab2.duesenListe.value, "Düsendurchmesser-Liste");
        par.chi_kalibrierwerte = Fmt.parseList(Tab2.chiListe.value, "Chi-Kalibrierwerte-Liste");
        return par;
    }

    function parameterAnwenden(par) {
        if (Presets.FUEL_PRESETS[par.brennstoff]) {
            brennstoffBox.value = par.brennstoff;
        }
        flascheBox.value = EIGENE_WERTE;
        vFl.value = Fmt.g6(par.V_FL * 1e3);
        dFl.value = Fmt.g6(par.D_FL * 1e3);
        lFl.value = Fmt.g6(par.L_FL * 1e3);
        mFl.value = Fmt.g6(par.M_FL * 1e3);
        cdAir.value = Fmt.g6(par.C_D_AIR);
        pBurst.value = Fmt.g6(par.P_BURST / 1e5);
        sMin.value = Fmt.g6(par.S_MIN);
        // Erst die Temperatur setzen (loest die Umrechnung der abhaengigen Tab-2-Felder aus),
        // danach ueberschreiben die geladenen Werte.
        umgebungSetzen(Fmt.g6(par.T_0 - Presets.KELVIN_OFFSET));
        umgebungAufTab2Anwenden();
        Tab2.ALLE_ATTRS.forEach(function (attr) {
            Tab2.setWert(attr, par[attr]);
        });
        Tab2.duesenListe.value = Fmt.joinList(par.duesendurchmesser_mm);
        Tab2.chiListe.value = Fmt.joinList(par.chi_kalibrierwerte);
    }

    // ------------------------------------------------------------------
    // JSON speichern / laden
    // ------------------------------------------------------------------
    async function parameterSpeichern() {
        var par;
        try {
            par = parameterSammeln();
        } catch (e) {
            await FR.Ui.meldung("Ungültige Eingabe", e.message, "fehler");
            return;
        }
        var erg;
        try {
            erg = await FR.Ui.dateiSpeichern({
                name: "flaschenrakete_parameter.json", text: FR.Json.toJson(par),
                mime: "application/json", beschreibung: "JSON-Datei (*.json)", endung: ".json"
            });
        } catch (e) {
            await FR.Ui.meldung("Fehler beim Speichern", "Datei konnte nicht gespeichert werden:\n" + e.message, "fehler");
            return;
        }
        if (!erg.ok) return;
        status(erg.download
            ? "Parameter als Download bereitgestellt: " + erg.name + " (Download-Ordner des Browsers)"
            : "Parameter gespeichert: " + erg.name);
    }

    async function parameterLaden() {
        var datei;
        try {
            datei = await FR.Ui.dateiLaden(".json,application/json");
        } catch (e) {
            await FR.Ui.meldung("Fehler beim Laden", "Datei konnte nicht geladen werden:\n" + e.message, "fehler");
            return;
        }
        if (!datei) return;
        var par;
        try {
            par = FR.Json.fromJson(datei.text);
        } catch (e) {
            await FR.Ui.meldung("Fehler beim Laden", "Datei konnte nicht geladen werden:\n" + e.message, "fehler");
            return;
        }
        try {
            // Temperatur ausserhalb 15 bis 35 C (z. B. alte Dateien mit 60 C) mit der Bereichsmeldung abweisen
            FR.Modell.pruefeUmgebungstemperatur(par);
        } catch (e) {
            await FR.Ui.meldung("Fehler beim Laden", "Datei konnte nicht geladen werden:\n" + e.message, "fehler");
            return;
        }
        parameterAnwenden(par);
        status("Parameter geladen: " + datei.name);
        if (par.ignoriert) {
            await FR.Ui.meldung("Ältere Parameterdatei",
                "Das veraltete Feld SIGMA wurde ignoriert: Das Expansionsverhältnis wird jetzt aus SIGMA_293, "
                + "SIGMA_SLOPE und der Umgebungstemperatur berechnet.\n\nHinweis: Die laminare Brenngeschwindigkeit "
                + "S_L wird im Modell ebenfalls aus der Umgebungstemperatur berechnet. Ein in der Datei "
                + "temperaturskaliert gespeichertes S_L sollte auf den Wert bei T_REF_SL (298,15 K) zurückgesetzt werden.",
                "info");
        }
    }

    // ------------------------------------------------------------------
    function init() {
        brennstoffBox = document.getElementById("brennstoff");
        flascheBox = document.getElementById("flasche");
        umgebungFeld = document.getElementById("umgebung");
        umgebungListe = document.getElementById("umgebungListe");
        umgebungPfeil = document.getElementById("umgebungPfeil");
        vFl = document.getElementById("vFl");
        dFl = document.getElementById("dFl");
        lFl = document.getElementById("lFl");
        mFl = document.getElementById("mFl");
        cdAir = document.getElementById("cdAir");
        pBurst = document.getElementById("pBurst");
        sMin = document.getElementById("sMin");
        statusEl = document.getElementById("startStatus");

        Presets.FUEL_NAMES.forEach(function (name) {
            brennstoffBox.appendChild(el("option", { value: name }, name));
        });
        Presets.BOTTLE_NAMES.concat([EIGENE_WERTE]).forEach(function (name) {
            flascheBox.appendChild(el("option", { value: name }, name));
        });
        temperaturListeAufbauen();

        umgebungFeld.addEventListener("input", beiTemperaturEingabe);
        brennstoffBox.addEventListener("change", beiBrennstoffGewaehlt);
        flascheBox.addEventListener("change", beiFlaschenPresetGewaehlt);
        [vFl, dFl, lFl, mFl].forEach(function (f) {
            f.addEventListener("input", beiFlaschenfeldGeaendert);
        });
        document.getElementById("btnSpeichern").addEventListener("click", parameterSpeichern);
        document.getElementById("btnLaden").addEventListener("click", parameterLaden);
        Tab2.setBeimZuruecksetzen(tab2Zuruecksetzen);

        // Startzustand wie im Python-Original
        tab2Zuruecksetzen();
        beiFlaschenPresetGewaehlt();
    }

    FR.StartTab = {
        init: init, parameterSammeln: parameterSammeln, parameterAnwenden: parameterAnwenden,
        status: status
    };
})(globalThis.FR = globalThis.FR || {});
