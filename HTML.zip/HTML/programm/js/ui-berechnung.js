/* Tab 3: Berechnung, Ergebnisdarstellung, Diagramme und CSV-Export (Port von BerechnungTab.java).
 * Die Rechnung laeuft in Portionen (eine Duese bzw. ein chi-Wert je Schritt) mit kurzen Pausen,
 * damit die Seite bedienbar bleibt und der Fortschrittsbalken echten Fortschritt zeigt.
 */
(function (FR) {
    "use strict";

    var Fmt = FR.Fmt;
    var Modell = FR.Modell;
    var el = FR.Ui.el;

    /** Hoechstzahl an Zeitschritten je Rechenlauf (Schutz gegen zu kleines DT bzw. zu grosses T_MAX). */
    var MAX_SCHRITTE = 2e7;

    var btn, fortschritt, statusEl, zusammenfassungEl, duesenBody, kalBody, csvName, btnCsv;
    var chartHoehe, chartSicherheit;
    var letztes = null;                 // letztes Gesamtergebnis {par, st, gd, erg, kal}
    var beiErgebnis = function () { };
    var laeuft = false;

    function setStatus(text) {
        statusEl.textContent = text;
    }

    /** Prueft Eingaben, die das Modell zum Absturz oder zu einer Endlosschleife bringen wuerden. */
    function numerikPruefen(par) {
        if (!(par.DT > 0)) {
            throw new Error("Der Zeitschritt DT muss größer als 0 sein (eingegeben: " + Fmt.g6(par.DT) + ").");
        }
        if (!(par.T_MAX > 0)) {
            throw new Error("Die Abbruchzeit T_MAX muss größer als 0 sein (eingegeben: " + Fmt.g6(par.T_MAX) + ").");
        }
        if (par.T_MAX / par.DT > MAX_SCHRITTE) {
            throw new Error("Zu viele Zeitschritte: T_MAX / DT = " + Fmt.g6(par.T_MAX / par.DT)
                + " (erlaubt sind höchstens " + Fmt.g6(MAX_SCHRITTE) + " je Rechenlauf).\n"
                + "Bitte DT vergrößern oder T_MAX verkleinern.");
        }
    }

    // ------------------------------------------------------------------
    // Berechnung
    // ------------------------------------------------------------------
    async function berechnen() {
        if (laeuft) return;
        var par;
        try {
            par = FR.StartTab.parameterSammeln();
            numerikPruefen(par);
        } catch (e) {
            await FR.Ui.meldung("Ungültige Eingabe", e.message, "fehler");
            return;
        }
        laeuft = true;
        btn.disabled = true;
        var nD = par.duesendurchmesser_mm.length;
        var nChi = par.chi_kalibrierwerte.length;
        var gesamt = nD + nChi * nD;
        var fertig = 0;
        fortschritt.max = gesamt;
        fortschritt.value = 0;
        setStatus("Berechnung läuft...");
        await FR.Ui.pause();

        try {
            var st = Modell.stoechiometrie(par);
            var gd = Modell.grenzdruck(par, st);
            var erg = [];
            var i, j;
            for (i = 0; i < nD; i++) {
                erg.push(Modell.duese(par, par.duesendurchmesser_mm[i], null));
                fortschritt.value = ++fertig;
                await FR.Ui.pause();
            }
            var kal = [];
            for (j = 0; j < nChi; j++) {
                var chi = par.chi_kalibrierwerte[j];
                var ergChi = [];
                for (i = 0; i < nD; i++) {
                    ergChi.push(Modell.duese(par, par.duesendurchmesser_mm[i], chi));
                    fortschritt.value = ++fertig;
                    await FR.Ui.pause();
                }
                kal.push(Modell.kalibrierungAusStudie(par, chi, ergChi));
            }
            letztes = { par: par, st: st, gd: gd, erg: erg, kal: kal };
            ergebnisAnzeigen(letztes);
            setStatus("Berechnung abgeschlossen.");
            beiErgebnis(letztes);
        } catch (e) {
            setStatus("Fehler bei der Berechnung.");
            await FR.Ui.meldung("Fehler bei der Berechnung", String(e && e.message), "fehler");
        } finally {
            laeuft = false;
            btn.disabled = false;
        }
    }

    // ------------------------------------------------------------------
    // Ergebnisdarstellung
    // ------------------------------------------------------------------
    /** "  Label" auf 38 Zeichen aufgefuellt, danach der Wert (Breite 8) und die Einheit. */
    function zeile(label, wert, einheit) {
        return "  " + Fmt.rechts(label, 36) + Fmt.links(wert, 8) + (einheit ? " " + einheit : "") + "\n";
    }

    function ergebnisAnzeigen(res) {
        var par = res.par, st = res.st, gd = res.gd, erg = res.erg;
        var f2 = function (x) { return Fmt.fest(x, 2); };

        var kopf = "Brennstoff: " + par.brennstoff + "\n\n"
            + "Stöchiometrie und Dosierung\n"
            + zeile("Luftbedarf", f2(st.n_L), "mol/mol")
            + zeile("Stöchiometrischer Volumenanteil", f2(st.phi * 100), "Vol.-%")
            + zeile("Stöchiometrisches Luftverhältnis", f2(st.L_st), "kg/kg")
            + zeile("Gemischheizwert", Fmt.fest(st.H_G / 1e6, 3), "MJ/kg")
            + zeile("Brennstoffmasse je Flasche", Fmt.fest(st.m_B_flasche * 1e3, 4), "g")
            + zeile("Brennstoffvolumen je Flasche", Fmt.fest(st.V_B_flasche * 1e6, 4), "ml")
            + zeile("Umgebungstemperatur T_amb", f2(par.T_0 - 273.15), "°C")
            + zeile("Expansionsverhältnis σ(T)", Fmt.fest(Modell.sigma(par), 4), "")
            + zeile("Lam. Brenngeschwindigk. S_L(T)", Fmt.fest(Modell.sL(par), 4), "m/s") + "\n"
            + "Isochore Druckobergrenze (geschlossene Flasche)\n"
            + zeile("Flammentemperatur extern (T_AD)", f2(gd.T_ad_extern), "K")
            + zeile("Flammentemperatur Energiebilanz", f2(gd.T_ad_bilanz), "K  (Plausibilitätsprüfung)")
            + zeile("Grenzdruck Molbilanz + T_AD", f2(gd.p_modell / 1e5), "bar")
            + zeile("Grenzdruck extern (Gleichgewicht)", f2(gd.p_extern / 1e5), "bar")
            + zeile("Abweichung Modell zu extern", Fmt.fest(gd.abweichung_pct, 1, 0, true), "%")
            + zeile("Auslegungswert (konservativ)", f2(gd.p_ausl / 1e5), "bar")
            + zeile("Mindestberstdruck", f2(par.P_BURST / 1e5), "bar")
            + "  " + Fmt.rechts("Sicherheitsfaktor", 36) + Fmt.links(f2(gd.sicherheitsfaktor), 8)
            + "  (gefordert: " + f2(par.S_MIN) + ")\n";

        var zulaessig = gd.sicherheitsfaktor >= par.S_MIN;
        var bewertung = "  Bewertung: " + (zulaessig ? "zulässig" : "unzulässig, Düsenbohrung zwingend erforderlich") + "\n";

        var best = Modell.optimum(erg);
        var rest = "\nFlugmechanische Kenngrößen\n"
            + zeile("Stirnfläche", f2(Math.PI / 4 * par.D_FL * par.D_FL * 1e4), "cm^2")
            + zeile("Grenzgeschwindigkeit", f2(Modell.grenzgeschwindigkeit(par)), "m/s")
            + "\nOptimum bei d = " + Fmt.g6(best.d_mm) + " mm, Gesamthöhe " + f2(best.hoehe_m) + " m (Brennphase "
            + f2(best.hoehe_brenn_m) + " m + Freiflug " + f2(best.hoehe_frei_m) + " m), Spitzendruck "
            + f2(best.p_max_bar) + " bar\n";

        zusammenfassungEl.textContent = "";
        zusammenfassungEl.appendChild(document.createTextNode(kopf));
        zusammenfassungEl.appendChild(el("span", { class: zulaessig ? "ok" : "schlecht" }, bewertung));
        zusammenfassungEl.appendChild(document.createTextNode(rest));

        // Duesenstudie
        duesenBody.textContent = "";
        erg.forEach(function (e) {
            var zeileEl = el("tr", e === best ? { class: "optimum" } : null);
            [Fmt.g6(e.d_mm), Fmt.fest(e.p_max_bar, 2), Fmt.fest(e.F_max_N, 2), Fmt.fest(e.impuls_Ns, 3),
             Fmt.fest(e.v_bo, 1), Fmt.fest(e.hoehe_brenn_m, 2), Fmt.fest(e.hoehe_frei_m, 2),
             Fmt.fest(e.hoehe_m, 2), Fmt.fest(e.sicherheitsfaktor, 1)].forEach(function (t) {
                zeileEl.appendChild(el("td", null, t));
            });
            duesenBody.appendChild(zeileEl);
        });

        // Kalibrierung (Spaltenreihenfolge: chi, d_opt, d_krit, Hoehe)
        kalBody.textContent = "";
        res.kal.forEach(function (k) {
            var zeileEl = el("tr");
            [Fmt.fest(k.chi, 2), Fmt.g6(k.d_opt_mm), Fmt.fest(k.d_krit_mm, 2), Fmt.fest(k.hoehe_m, 2)].forEach(function (t) {
                zeileEl.appendChild(el("td", null, t));
            });
            kalBody.appendChild(zeileEl);
        });

        // Diagramme
        var xs = [], hoehe = [], sicher = [], bestIdx = 0;
        erg.forEach(function (e, i) {
            xs.push(e.d_mm);
            hoehe.push(e.hoehe_m);
            sicher.push(e.sicherheitsfaktor);
            if (hoehe[i] > hoehe[bestIdx]) bestIdx = i;
        });
        chartHoehe.setDaten(xs, hoehe, "Steighöhe über Düsendurchmesser", "d [mm]", "Höhe [m]", bestIdx, null, null);
        chartSicherheit.setDaten(xs, sicher, "Sicherheitsfaktor über Düsendurchmesser", "d [mm]", "Sicherheit [-]",
            bestIdx, par.S_MIN, "S_MIN=" + Fmt.g6(par.S_MIN));

        csvName.value = FR.Csv.standardName(par.brennstoff);
    }

    // ------------------------------------------------------------------
    // CSV-Export
    // ------------------------------------------------------------------
    async function csvSpeichern() {
        if (!letztes) {
            await FR.Ui.meldung("Keine Ergebnisse", "Bitte zuerst eine Berechnung durchführen.", "info");
            return;
        }
        var name = csvName.value.trim();
        if (name === "") name = FR.Csv.standardName(letztes.par.brennstoff);
        if (name.indexOf(".") < 0) name += ".csv";
        var erg;
        try {
            erg = await FR.Ui.dateiSpeichern({
                name: name, text: FR.Csv.zeilen(letztes.erg), mime: "text/csv",
                beschreibung: "CSV-Datei (*.csv)", endung: ".csv"
            });
        } catch (e) {
            await FR.Ui.meldung("Fehler beim Speichern", "Datei konnte nicht gespeichert werden:\n" + e.message, "fehler");
            return;
        }
        if (!erg.ok) return;
        setStatus(erg.download
            ? "CSV als Download bereitgestellt: " + erg.name + " (Download-Ordner des Browsers)"
            : "CSV gespeichert: " + erg.name);
    }

    // ------------------------------------------------------------------
    function init() {
        btn = document.getElementById("btnBerechnen");
        fortschritt = document.getElementById("fortschritt");
        statusEl = document.getElementById("berStatus");
        zusammenfassungEl = document.getElementById("zusammenfassung");
        duesenBody = document.getElementById("duesenBody");
        kalBody = document.getElementById("kalBody");
        csvName = document.getElementById("csvName");
        btnCsv = document.getElementById("btnCsv");
        chartHoehe = FR.Diagramm.erzeugen(document.getElementById("chartHoehe"));
        chartSicherheit = FR.Diagramm.erzeugen(document.getElementById("chartSicherheit"));

        btn.addEventListener("click", berechnen);
        btnCsv.addEventListener("click", csvSpeichern);
    }

    FR.BerechnungTab = {
        init: init, setStatus: setStatus,
        setBeiErgebnis: function (fn) { beiErgebnis = fn; },
        get letztes() { return letztes; }
    };
})(globalThis.FR = globalThis.FR || {});
