/* Presets fuer Brennstoff und Flaschengeometrie (Port von Presets.java,
 * entspricht flaschenrakete_presets.py). Herkunft der Werte siehe README.md
 * (NASA CEA/CEARUN fuer T_AD und P_ISO_EXT, uebrige Werte Literatur bzw.
 * eigene Messungen).
 */
(function (FR) {
    "use strict";

    /** Namen der Brennstoff-Felder, die ein Preset setzt. */
    var FUEL_ATTRS = ["M_B", "RHO_B", "H_U", "N_O2", "N_PROD", "S_L", "SIGMA_293", "SIGMA_SLOPE", "T_AD", "P_ISO_EXT"];

    // Expansionsverhaeltnis: sigma(T) = SIGMA_293 + SIGMA_SLOPE * (T - 293,15 K), eigene
    // Gleichgewichtsrechnung (Cantera 3.2.0, HP-Gleichgewicht mit Dissoziation, phi = 1, 1,013 bar).
    // S_L gilt bei T_REF_SL (298,15 K); die Temperaturabhaengigkeit berechnet das Modell selbst.
    function brennstoff(name, M_B, RHO_B, H_U, N_O2, N_PROD, S_L, SIGMA_293, SIGMA_SLOPE, T_AD, P_ISO_EXT) {
        return {
            brennstoff: name, M_B: M_B, RHO_B: RHO_B, H_U: H_U, N_O2: N_O2, N_PROD: N_PROD,
            S_L: S_L, SIGMA_293: SIGMA_293, SIGMA_SLOPE: SIGMA_SLOPE, T_AD: T_AD, P_ISO_EXT: P_ISO_EXT
        };
    }

    function flasche(V_FL, D_FL, L_FL, M_FL) {
        return { V_FL: V_FL, D_FL: D_FL, L_FL: L_FL, M_FL: M_FL };
    }

    // Reihenfolge = Reihenfolge im Dropdown.
    var FUEL_NAMES = ["Isopropanol", "Methanol", "Ethanol"];
    var FUEL_PRESETS = {
        "Isopropanol": brennstoff("Isopropanol",
            60.10e-3, 786.0, 30.45e6, 4.5, 7.0, 0.40, 8.2226, -0.02621, 2595.77, 9.02e5),
        "Methanol": brennstoff("Methanol",
            32.04e-3, 792.0, 19.90e6, 1.5, 3.0, 0.45, 8.1089, -0.02588, 2570.36, 9.18e5),
        // Ethanol C2H5OH: N_O2 = 2 + 6/4 - 1/2 = 3, N_PROD = 2 CO2 + 3 H2O = 5.
        "Ethanol": brennstoff("Ethanol",
            46.07e-3, 789.0, 26.8e6, 3.0, 5.0, 0.41, 8.1992, -0.02616, 2590.71, 9.0697e5)
    };

    // Eigene Messungen (Durchmesser, Innenhoehe, Leermasse). V_FL ist das
    // aufgedruckte Nennvolumen, nicht das geometrische Zylindervolumen.
    var BOTTLE_NAMES = [
        "1,25 L Referenz (Pepsi)",
        "1,0 L Einweg (Aldi Eistee)",
        "1,0 L Mehrweg (Coca-Cola)",
        "1,5 L Einweg (Aldi River Cola)"
    ];
    var BOTTLE_PRESETS = {
        "1,25 L Referenz (Pepsi)": flasche(1.25e-3, 0.080, 0.270, 0.0367),
        "1,0 L Einweg (Aldi Eistee)": flasche(1.00e-3, 0.078, 0.270, 0.0343),
        "1,0 L Mehrweg (Coca-Cola)": flasche(1.00e-3, 0.081, 0.250, 0.0738),
        "1,5 L Einweg (Aldi River Cola)": flasche(1.50e-3, 0.086, 0.295, 0.0263)
    };

    // --- Umgebungstemperatur ----------------------------------------------
    // Eine Temperatur fuer Flasche, Gemisch, Wand und umgebende Luft. Zulaessig sind 15 bis 35 C
    // (= 288,15 bis 308,15 K; das Modell wirft ausserhalb einen Fehler).
    var T_UMGEBUNG_MIN_C = 15.0;
    var T_UMGEBUNG_MAX_C = 35.0;
    var T_UMGEBUNG_STANDARD_C = 25.0;

    var KELVIN_OFFSET = 273.15;
    var T_REF_K = 298.15;      // Bezugstemperatur der Luftdichte (25 C)
    var RHO_L_REF = 1.20;      // kg/m^3, Luftdichte bei T_REF_K

    function celsiusZuKelvin(tC) {
        return tC + KELVIN_OFFSET;
    }

    /** Schreibt die Brennstoffdaten eines Presets in einen Parametersatz. */
    function brennstoffAnwenden(par, preset) {
        par.brennstoff = preset.brennstoff;
        for (var i = 0; i < FUEL_ATTRS.length; i++) {
            par[FUEL_ATTRS[i]] = preset[FUEL_ATTRS[i]];
        }
    }

    /**
     * Temperaturabhaengige Modelleingaben fuer eine Umgebungstemperatur [C]: T_0, T_WALL und
     * RHO_L (ideales Gas, ueber 15 bis 35 C rund +-3 %). S_L und sigma berechnet das Modell
     * selbst aus T_0 (Modell.sL, Modell.sigma). T_AD und P_ISO_EXT bleiben bewusst unveraendert.
     */
    function umgebungswerte(tC) {
        var T = celsiusZuKelvin(tC);
        var werte = {};
        werte.T_0 = T;
        werte.T_WALL = T;
        werte.RHO_L = RHO_L_REF * T_REF_K / T;
        return werte;
    }

    FR.Presets = {
        FUEL_ATTRS: FUEL_ATTRS, FUEL_NAMES: FUEL_NAMES, FUEL_PRESETS: FUEL_PRESETS,
        BOTTLE_NAMES: BOTTLE_NAMES, BOTTLE_PRESETS: BOTTLE_PRESETS,
        T_UMGEBUNG_MIN_C: T_UMGEBUNG_MIN_C, T_UMGEBUNG_MAX_C: T_UMGEBUNG_MAX_C,
        T_UMGEBUNG_STANDARD_C: T_UMGEBUNG_STANDARD_C,
        KELVIN_OFFSET: KELVIN_OFFSET, T_REF_K: T_REF_K, RHO_L_REF: RHO_L_REF,
        celsiusZuKelvin: celsiusZuKelvin, brennstoffAnwenden: brennstoffAnwenden,
        umgebungswerte: umgebungswerte
    };
})(globalThis.FR = globalThis.FR || {});
