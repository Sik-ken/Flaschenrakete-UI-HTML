/* Alle Stoff-, Modell- und Versuchswerte an einer Stelle (Port von Parameter.java).
 * Feldnamen und Defaults sind identisch zum Python-Original, damit auch die
 * JSON-Dateien austauschbar bleiben.
 *
 * Herkunft der Defaults: [S] Literatur, [G] eigene Messung, [A] Annahme,
 * [K] an der eigenen Messung kalibriert, [R] eigene Rechnung.
 */
(function (FR) {
    "use strict";

    /** Skalare Zahlenfelder in Reihenfolge der Python-Datenklasse. */
    var NUMERIC_FIELDS = [
        "M_B", "RHO_B", "H_U", "N_O2", "N_PROD", "S_L", "T_REF_SL", "N_SL", "SIGMA_293", "SIGMA_SLOPE",
        "T_AD", "P_ISO_EXT",
        "M_L", "Y_O2", "R_UNIV", "R_S", "KAPPA", "KAPPA_U", "T_0", "P_0", "RHO_L", "G",
        "CHI", "C_D_HOLE", "H_WALL", "T_WALL", "ETA_C",
        "V_FL", "D_FL", "L_FL", "M_FL", "C_D_AIR", "P_BURST", "S_MIN",
        "DT", "T_MAX"
    ];

    function Parameter() {
        // --- Brennstoff ----------------------------------------------------
        this.brennstoff = "Isopropanol";
        this.M_B       = 60.10e-3;   // kg/mol   Molmasse Brennstoff                 [S]
        this.RHO_B     = 786.0;      // kg/m^3   Dichte fluessig bei 20 C            [S]
        this.H_U       = 30.45e6;    // J/kg     unterer Heizwert                    [S]
        this.N_O2      = 4.5;        // mol/mol  Sauerstoffbedarf je mol Brennstoff  [S]
        this.N_PROD    = 7.0;        // mol/mol  gasfoermige Produkte (3 CO2+4 H2O)  [S]
        this.S_L       = 0.40;       // m/s      laminare Brenngeschwindigkeit bei T_REF_SL [S]
        this.T_REF_SL  = 298.15;     // K        Referenztemperatur fuer S_L (CHI/H_WALL-Kalibrierung)  [A]
        this.N_SL      = 1.75;       // -        Temperaturexponent S_L: Gülder (1982) fuer Methanol/Ethanol [S],
                                     //          fuer Isopropanol analog uebernommen [A]
        // Expansionsverhaeltnis rho_u/rho_b, linear in T_amb (Stuetzstelle 293,15 K), eigene
        // Gleichgewichtsrechnung (Cantera 3.2.0, HP, phi = 1, 1,013 bar), gueltig 278 bis 308 K:
        this.SIGMA_293   = 8.2226;   // -        Expansionsverhaeltnis bei 293,15 K (Isopropanol)  [R]
        this.SIGMA_SLOPE = -0.02621; // 1/K      Steigung des Expansionsverhaeltnisses             [R]
        this.T_AD      = 2595.77;    // K        isochore Flammentemperatur, extern  [S]
        this.P_ISO_EXT = 9.02e5;     // Pa       isochorer Grenzdruck, extern        [S]

        // --- Luft und Umgebung ---------------------------------------------
        this.M_L     = 28.96e-3;     // kg/mol    Molmasse Luft                      [S]
        this.Y_O2    = 0.2095;       // -         Sauerstoffanteil der Luft          [S]
        this.R_UNIV  = 8.314;        // J/(mol K) universelle Gaskonstante           [S]
        this.R_S     = 287.0;        // J/(kg K)  spez. Gaskonstante des Gemisches   [A]
        this.KAPPA   = 1.25;         // -         Isentropenexponent heisses Abgas   [A]
        this.KAPPA_U = 1.38;         // -         Isentropenexponent kaltes Frischgas[S]
        this.T_0     = 298.15;       // K         Umgebungstemperatur                [G]
        this.P_0     = 1.013e5;      // Pa        Umgebungsdruck                     [G]
        this.RHO_L   = 1.20;         // kg/m^3    Luftdichte                         [S]
        this.G       = 9.81;         // m/s^2     Erdbeschleunigung                  [S]

        // --- Modellparameter -----------------------------------------------
        this.CHI      = 2.25;        // -         Flammenfaltungsfaktor              [K]
        this.C_D_HOLE = 0.80;        // -         Durchflusszahl der Bohrung         [A]
        this.H_WALL   = 100.0;       // W/(m^2 K) Wandwaermeuebergang                [K]
        this.T_WALL   = 298.15;      // K         Wandtemperatur                     [A]
        this.ETA_C    = 0.95;        // -         Verbrennungswirkungsgrad           [A]

        // --- Flasche und Flug ----------------------------------------------
        this.V_FL    = 1.25e-3;      // m^3   Flaschenvolumen                        [G]
        this.D_FL    = 0.080;        // m     Flaschendurchmesser                    [G]
        this.L_FL    = 0.270;        // m     Innenhoehe der Flasche                 [G]
        this.M_FL    = 0.0367;       // kg    Leermasse der Flasche                  [G]
        this.C_D_AIR = 0.60;         // -     Widerstandsbeiwert                     [A]
        this.P_BURST = 14.0e5;       // Pa    Mindestberstdruck                      [S]
        this.S_MIN   = 2.0;          // -     geforderter Sicherheitsfaktor          [A]

        // --- Numerik -------------------------------------------------------
        this.DT    = 1.0e-5;         // s     Zeitschritt
        this.T_MAX = 1.0;            // s     Abbruchzeit

        // --- Duesenstudie und Kalibrierung ---------------------------------
        this.duesendurchmesser_mm = [4, 5, 6, 7, 8, 10, 12, 16];
        this.chi_kalibrierwerte   = [1.75, 2.0, 2.25, 2.5, 3.0];
    }

    /** Spezifische Waermekapazitaet bei konstantem Volumen. */
    Parameter.prototype.cv = function () {
        return this.R_S / (this.KAPPA - 1.0);
    };

    /** Spezifische Waermekapazitaet bei konstantem Druck. */
    Parameter.prototype.cp = function () {
        return this.cv() + this.R_S;
    };

    /** Tiefe Kopie (entspricht dataclasses.replace). */
    Parameter.prototype.copy = function () {
        var p = new Parameter();
        for (var i = 0; i < NUMERIC_FIELDS.length; i++) {
            p[NUMERIC_FIELDS[i]] = this[NUMERIC_FIELDS[i]];
        }
        p.brennstoff = this.brennstoff;
        p.duesendurchmesser_mm = this.duesendurchmesser_mm.slice();
        p.chi_kalibrierwerte = this.chi_kalibrierwerte.slice();
        return p;
    };

    FR.Parameter = Parameter;
    FR.NUMERIC_FIELDS = NUMERIC_FIELDS;
})(globalThis.FR = globalThis.FR || {});
