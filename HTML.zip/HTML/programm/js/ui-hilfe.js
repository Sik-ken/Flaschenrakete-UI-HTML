/* Benutzerhandbuch: Markdown-Text (programm/js/hilfe-inhalt.js, erzeugt mit programm/test/hilfe_bauen.py) als eigene,
 * scrollbare Seite. Die Abbildungen liegen in programm/res.
 *
 * Der Renderer kennt nur die Markdown-Elemente, die das Handbuch verwendet: Ueberschriften (# bis ###), Absaetze,
 * nummerierte Listen und Aufzaehlungen, Pipe-Tabellen, Bilder mit Unterschrift, **fett**, *kursiv*, `code`
 * und Links [Text](https://...).
 * Alles wird HTML-escaped; Unterstriche (T_0, RHO_L) bleiben Text.
 */
(function (FR) {
    "use strict";

    // ------------------------------------------------------------------
    // Markdown -> HTML
    // ------------------------------------------------------------------
    function esc(s) {
        return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    }

    /** Inline-Formatierung: Code schuetzen, escapen, dann fett und kursiv. */
    function inline(text) {
        var codes = [];
        var t = text.replace(/`([^`]+)`/g, function (m, c) {
            codes.push(c);
            return "\u0000" + (codes.length - 1) + "\u0000";
        });
        t = esc(t);
        // Links [Text](https://...): nur http/https, oeffnen im neuen Tab (Anfuehrungszeichen sind bereits escaped)
        t = t.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,
            "<a href=\"$2\" target=\"_blank\" rel=\"noopener noreferrer\">$1</a>");
        t = t.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
        t = t.replace(/\*([^*\n]+)\*/g, "<em>$1</em>");
        return t.replace(/\u0000(\d+)\u0000/g, function (m, i) {
            return "<code>" + esc(codes[+i]) + "</code>";
        });
    }

    var RE_UEBERSCHRIFT = /^(#{1,3})\s+(.*)$/;
    var RE_TABELLENTRENNER = /^\s*\|[\s:|-]+\|\s*$/;
    var RE_GEORDNET = /^\d+\.\s+(.*)$/;
    var RE_AUFZAEHLUNG = /^-\s+(.*)$/;
    var RE_BILD = /^!\[([^\]]*)\]\((?:<([^>]+)>|([^)\s]+))\)\s*$/;
    var RE_KURSIVZEILE = /^\*([^*].*)\*$/;

    function zellen(zeile) {
        var s = zeile.trim();
        if (s.charAt(0) === "|") s = s.slice(1);
        if (s.charAt(s.length - 1) === "|") s = s.slice(0, -1);
        return s.split("|").map(function (c) { return c.trim(); });
    }

    function istBlockStart(zeilen, i) {
        var z = zeilen[i];
        return RE_UEBERSCHRIFT.test(z) || RE_GEORDNET.test(z) || RE_AUFZAEHLUNG.test(z) || RE_BILD.test(z.trim())
            || (/^\s*\|/.test(z) && i + 1 < zeilen.length && RE_TABELLENTRENNER.test(zeilen[i + 1]));
    }

    /** Wandelt den Handbuchtext in HTML um. bilder: Name aus der MD -> Pfad der Anzeigedatei (relativ zu START.html). */
    function markdownZuHtml(md, bilder) {
        bilder = bilder || {};
        var zeilen = String(md).replace(/\r\n?/g, "\n").replace(/<!--[\s\S]*?-->/g, "").split("\n");
        var out = [];
        var i = 0;
        var m;

        while (i < zeilen.length) {
            var z = zeilen[i];
            if (/^\s*$/.test(z)) { i++; continue; }

            if ((m = RE_UEBERSCHRIFT.exec(z))) {
                var n = m[1].length;
                out.push("<h" + n + ">" + inline(m[2].trim()) + "</h" + n + ">");
                i++;
                continue;
            }

            if (/^\s*\|/.test(z) && i + 1 < zeilen.length && RE_TABELLENTRENNER.test(zeilen[i + 1])) {
                var kopf = zellen(z);
                var t = ["<div class=\"hilfe-tabelle" + (kopf[0] === "Nr." ? " nr" : "") + "\"><table><thead><tr>"];
                kopf.forEach(function (c) { t.push("<th>" + inline(c) + "</th>"); });
                t.push("</tr></thead><tbody>");
                i += 2;
                while (i < zeilen.length && /^\s*\|/.test(zeilen[i])) {
                    t.push("<tr>");
                    zellen(zeilen[i]).forEach(function (c) { t.push("<td>" + inline(c) + "</td>"); });
                    t.push("</tr>");
                    i++;
                }
                t.push("</tbody></table></div>");
                out.push(t.join(""));
                continue;
            }

            if (RE_GEORDNET.test(z) || RE_AUFZAEHLUNG.test(z)) {
                var geordnet = RE_GEORDNET.test(z);
                var re = geordnet ? RE_GEORDNET : RE_AUFZAEHLUNG;
                var liste = [geordnet ? "<ol>" : "<ul>"];
                while (i < zeilen.length && (m = re.exec(zeilen[i]))) {
                    liste.push("<li>" + inline(m[1].trim()) + "</li>");
                    i++;
                }
                liste.push(geordnet ? "</ol>" : "</ul>");
                out.push(liste.join(""));
                continue;
            }

            if ((m = RE_BILD.exec(z.trim()))) {
                var name = m[2] || m[3];
                var pfad = bilder[name] || ("programm/res/" + name);
                i++;
                var vorschau = i;                       // direkt folgende (ggf. nach einer Leerzeile) reine Kursivzeile = Unterschrift
                while (vorschau < zeilen.length && /^\s*$/.test(zeilen[vorschau])) vorschau++;
                var unterschrift = "";
                var kursiv = (vorschau < zeilen.length && vorschau - i <= 1) ? RE_KURSIVZEILE.exec(zeilen[vorschau].trim()) : null;
                if (kursiv) {
                    unterschrift = "<figcaption>" + inline(kursiv[1]) + "</figcaption>";
                    i = vorschau + 1;
                }
                out.push("<figure class=\"hilfe-abb\"><img src=\"" + esc(encodeURI(pfad)) + "\" alt=\"" + esc(m[1])
                    + "\" loading=\"lazy\" decoding=\"async\">" + unterschrift + "</figure>");
                continue;
            }

            // Absatz: bis zur Leerzeile oder bis zum naechsten Block
            var teile = [z.trim()];
            i++;
            while (i < zeilen.length && !/^\s*$/.test(zeilen[i]) && !istBlockStart(zeilen, i)) {
                teile.push(zeilen[i].trim());
                i++;
            }
            var absatz = teile.join(" ");
            out.push("<p" + (/^\*\*Tabelle \d+:/.test(absatz) ? " class=\"hilfe-tabellentitel\"" : "") + ">" + inline(absatz) + "</p>");
        }
        return out.join("\n");
    }

    // ------------------------------------------------------------------
    // Seite oeffnen / schliessen
    // ------------------------------------------------------------------
    var knopf, ebene, scroll, inhalt, schliessenKnopf;
    var offen = false;
    var gerendert = false;
    var HINTERGRUND = ["header.kopf", "nav.tabs", "main", "noscript"];

    function hintergrundSperren(sperren) {
        HINTERGRUND.forEach(function (sel) {
            var el = document.querySelector(sel);
            if (!el) return;
            if (sperren) el.setAttribute("inert", "");
            else el.removeAttribute("inert");
        });
        document.body.classList.toggle("hilfe-offen", sperren);
    }

    /** Fehlende Bilder: Alt-Text als Platzhalter statt eines kaputten Symbols. */
    function bildfehlerBehandeln() {
        Array.prototype.forEach.call(inhalt.querySelectorAll("img"), function (img) {
            img.addEventListener("error", function () {
                var ersatz = document.createElement("div");
                ersatz.className = "hilfe-bild-fehlt";
                ersatz.textContent = "[Abbildung nicht verfügbar: " + (img.getAttribute("alt") || "") + "]";
                if (img.parentNode) img.parentNode.replaceChild(ersatz, img);
            });
        });
    }

    function oeffnen() {
        if (offen) return;
        if (typeof FR.hilfeMarkdown !== "string") {
            FR.Ui.meldung("Handbuch nicht verfügbar",
                "Die Datei programm/js/hilfe-inhalt.js wurde nicht geladen. Bitte den Programmordner vollständig entpacken.", "fehler");
            return;
        }
        if (!gerendert) {
            inhalt.innerHTML = markdownZuHtml(FR.hilfeMarkdown, FR.hilfeBilder);
            bildfehlerBehandeln();
            gerendert = true;
        }
        ebene.hidden = false;
        hintergrundSperren(true);
        scroll.scrollTop = 0;
        scroll.focus();
        knopf.setAttribute("aria-expanded", "true");
        offen = true;
    }

    function schliessen() {
        if (!offen) return;
        ebene.hidden = true;
        hintergrundSperren(false);
        knopf.setAttribute("aria-expanded", "false");
        offen = false;
        knopf.focus();
    }

    function init() {
        knopf = document.getElementById("hilfeBtn");
        ebene = document.getElementById("hilfe");
        scroll = document.getElementById("hilfeScroll");
        inhalt = document.getElementById("hilfeInhalt");
        schliessenKnopf = document.getElementById("hilfeSchliessen");
        if (!knopf || !ebene) return;
        knopf.addEventListener("click", oeffnen);
        schliessenKnopf.addEventListener("click", schliessen);
        document.addEventListener("keydown", function (e) {
            // Esc schliesst die Hilfe, ausser ein Meldungsfenster ist offen (dann schliesst Esc nur dieses)
            if (offen && e.key === "Escape" && document.getElementById("modal").hidden) {
                e.preventDefault();
                schliessen();
            }
        });
    }

    FR.Hilfe = { init: init, oeffnen: oeffnen, schliessen: schliessen, markdownZuHtml: markdownZuHtml };
})(globalThis.FR = globalThis.FR || {});
