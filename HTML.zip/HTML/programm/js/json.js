/* Minimaler JSON-Leser/-Schreiber fuer die Parameterdateien (Port von MiniJson.java).
 * Schluesselnamen und Reihenfolge entsprechen dem Python-
 * json.dump(dataclasses.asdict(par), indent=2), so dass in Python oder Java
 * gespeicherte Dateien hier geladen werden koennen und umgekehrt.
 * Eigener Parser (statt JSON.parse), damit auch NaN/Infinity aus Python gelesen werden
 * und die Fehlermeldungen wie in der Java-Version lauten.
 */
(function (FR) {
    "use strict";

    var Fmt = FR.Fmt;
    var NUMERIC_FIELDS = FR.NUMERIC_FIELDS;

    // ------------------------------------------------------------------
    // Schreiben
    // ------------------------------------------------------------------
    function liste(werte) {
        var sb = "[\n";
        for (var i = 0; i < werte.length; i++) {
            sb += "    " + Fmt.repr(werte[i]) + (i < werte.length - 1 ? ",\n" : "\n");
        }
        return sb + "  ]";
    }

    function quote(s) {
        var sb = "\"";
        for (var i = 0; i < s.length; i++) {
            var c = s.charAt(i);
            var code = s.charCodeAt(i);
            if (c === "\"") sb += "\\\"";
            else if (c === "\\") sb += "\\\\";
            else if (c === "\n") sb += "\\n";
            else if (c === "\r") sb += "\\r";
            else if (c === "\t") sb += "\\t";
            else if (code < 0x20) sb += "\\u" + ("0000" + code.toString(16)).slice(-4);
            else sb += c;
        }
        return sb + "\"";
    }

    function toJson(par) {
        var sb = "{\n";
        sb += "  \"brennstoff\": " + quote(par.brennstoff);
        for (var i = 0; i < NUMERIC_FIELDS.length; i++) {
            var name = NUMERIC_FIELDS[i];
            sb += ",\n  \"" + name + "\": " + Fmt.repr(par[name]);
        }
        sb += ",\n  \"duesendurchmesser_mm\": " + liste(par.duesendurchmesser_mm);
        sb += ",\n  \"chi_kalibrierwerte\": " + liste(par.chi_kalibrierwerte);
        sb += "\n}\n";
        return sb;
    }

    // ------------------------------------------------------------------
    // Lesen
    // ------------------------------------------------------------------
    /** Kleiner rekursiver JSON-Parser (Objekt, Array, String, Zahl, true/false/null, NaN, Infinity). */
    function Reader(s) {
        this.s = s;
        this.pos = 0;
    }

    Reader.prototype.parseDocument = function () {
        this.skipWs();
        var v = this.parseValue();
        this.skipWs();
        if (this.pos !== this.s.length) throw this.error("Unerwartete Zeichen nach dem JSON-Wert");
        return v;
    };

    Reader.prototype.error = function (msg) {
        return new Error("Ungültiges JSON: " + msg + " (Position " + this.pos + ")");
    };

    Reader.prototype.skipWs = function () {
        while (this.pos < this.s.length && /\s/.test(this.s.charAt(this.pos))) this.pos++;   // \s enthaelt auch das BOM
    };

    Reader.prototype.parseValue = function () {
        var s = this.s;
        if (this.pos >= s.length) throw this.error("Unerwartetes Ende");
        var c = s.charAt(this.pos);
        if (c === "{") return this.parseObject();
        if (c === "[") return this.parseArray();
        if (c === "\"") return this.parseString();
        if (s.startsWith("true", this.pos)) { this.pos += 4; return true; }
        if (s.startsWith("false", this.pos)) { this.pos += 5; return false; }
        if (s.startsWith("null", this.pos)) { this.pos += 4; return null; }
        if (s.startsWith("NaN", this.pos)) { this.pos += 3; return NaN; }
        if (s.startsWith("Infinity", this.pos)) { this.pos += 8; return Infinity; }
        if (s.startsWith("-Infinity", this.pos)) { this.pos += 9; return -Infinity; }
        return this.parseNumber();
    };

    /** Liefert eine Liste von [Schluessel, Wert]-Paaren in Dateireihenfolge (spaeterer Schluessel gewinnt beim Anwenden). */
    Reader.prototype.parseObject = function () {
        var eintraege = [];
        var s = this.s;
        this.pos++;
        this.skipWs();
        if (this.pos < s.length && s.charAt(this.pos) === "}") { this.pos++; return { objekt: eintraege }; }
        while (true) {
            this.skipWs();
            if (this.pos >= s.length || s.charAt(this.pos) !== "\"") throw this.error("Schlüssel erwartet");
            var key = this.parseString();
            this.skipWs();
            if (this.pos >= s.length || s.charAt(this.pos) !== ":") throw this.error("':' erwartet");
            this.pos++;
            this.skipWs();
            eintraege.push([key, this.parseValue()]);
            this.skipWs();
            if (this.pos >= s.length) throw this.error("Unerwartetes Ende");
            var c = s.charAt(this.pos++);
            if (c === "}") return { objekt: eintraege };
            if (c !== ",") throw this.error("',' oder '}' erwartet");
        }
    };

    Reader.prototype.parseArray = function () {
        var list = [];
        var s = this.s;
        this.pos++;
        this.skipWs();
        if (this.pos < s.length && s.charAt(this.pos) === "]") { this.pos++; return list; }
        while (true) {
            this.skipWs();
            list.push(this.parseValue());
            this.skipWs();
            if (this.pos >= s.length) throw this.error("Unerwartetes Ende");
            var c = s.charAt(this.pos++);
            if (c === "]") return list;
            if (c !== ",") throw this.error("',' oder ']' erwartet");
        }
    };

    Reader.prototype.parseString = function () {
        var s = this.s;
        var sb = "";
        this.pos++; // Anfuehrungszeichen
        while (this.pos < s.length) {
            var c = s.charAt(this.pos++);
            if (c === "\"") return sb;
            if (c === "\\") {
                if (this.pos >= s.length) break;
                var e = s.charAt(this.pos++);
                switch (e) {
                    case "\"": sb += "\""; break;
                    case "\\": sb += "\\"; break;
                    case "/": sb += "/"; break;
                    case "b": sb += "\b"; break;
                    case "f": sb += "\f"; break;
                    case "n": sb += "\n"; break;
                    case "r": sb += "\r"; break;
                    case "t": sb += "\t"; break;
                    case "u":
                        if (this.pos + 4 > s.length || !/^[0-9a-fA-F]{4}$/.test(s.substr(this.pos, 4))) {
                            throw this.error("Ungültige \\u-Sequenz");
                        }
                        sb += String.fromCharCode(parseInt(s.substr(this.pos, 4), 16));
                        this.pos += 4;
                        break;
                    default: throw this.error("Ungültige Escape-Sequenz");
                }
            } else {
                sb += c;
            }
        }
        throw this.error("String nicht abgeschlossen");
    };

    Reader.prototype.parseNumber = function () {
        var s = this.s;
        var start = this.pos;
        while (this.pos < s.length && "+-0123456789.eE".indexOf(s.charAt(this.pos)) >= 0) this.pos++;
        if (start === this.pos) throw this.error("Wert erwartet");
        var text = s.substring(start, this.pos);
        var wert = /^[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$/.test(text) ? Number(text) : NaN;
        if (isNaN(wert)) throw this.error("Ungültige Zahl");
        return wert;
    };

    function isNumericField(key) {
        return NUMERIC_FIELDS.indexOf(key) >= 0;
    }

    function zahlenListe(key, val) {
        if (!Array.isArray(val) || val.length === 0) {
            throw new Error("'" + key + "' muss eine nicht-leere Zahlenliste sein.");
        }
        var out = [];
        for (var i = 0; i < val.length; i++) {
            if (typeof val[i] !== "number") {
                throw new Error("'" + key + "' darf nur Zahlen enthalten.");
            }
            out.push(val[i]);
        }
        return out;
    }

    /** Liest einen Parametersatz; fehlende Felder behalten ihren Default, unbekannte Felder sind ein Fehler. */
    function fromJson(text) {
        var root = new Reader(String(text)).parseDocument();
        if (root === null || typeof root !== "object" || !root.objekt) {
            throw new Error("JSON-Objekt erwartet.");
        }
        var par = new FR.Parameter();
        var gelesen = {};
        var ignoriert = [];
        for (var i = 0; i < root.objekt.length; i++) {
            var key = root.objekt[i][0];
            var val = root.objekt[i][1];
            gelesen[key] = true;
            if (key === "SIGMA") {
                // Aeltere Dateien: festes Expansionsverhaeltnis, gibt es nicht mehr (sigma(T) kommt aus
                // SIGMA_293/SIGMA_SLOPE und T_0). Wird ignoriert und der Oberflaeche gemeldet.
                ignoriert.push(key);
            } else if (key === "brennstoff") {
                if (typeof val !== "string") throw new Error("'brennstoff' muss Text sein.");
                par.brennstoff = val;
            } else if (key === "duesendurchmesser_mm") {
                par.duesendurchmesser_mm = zahlenListe(key, val);
            } else if (key === "chi_kalibrierwerte") {
                par.chi_kalibrierwerte = zahlenListe(key, val);
            } else {
                if (!isNumericField(key)) throw new Error("Unbekanntes Feld '" + key + "'.");
                if (typeof val !== "number") throw new Error("'" + key + "' muss eine Zahl sein.");
                par[key] = val;
            }
        }
        // Fehlende sigma-Parameter kommen aus dem Brennstoff-Preset statt aus dem Isopropanol-Default.
        var preset = FR.Presets.FUEL_PRESETS[par.brennstoff];
        if (preset) {
            if (!gelesen.SIGMA_293) par.SIGMA_293 = preset.SIGMA_293;
            if (!gelesen.SIGMA_SLOPE) par.SIGMA_SLOPE = preset.SIGMA_SLOPE;
        }
        if (ignoriert.length > 0) par.ignoriert = ignoriert;
        return par;
    }

    FR.Json = { toJson: toJson, fromJson: fromJson };
})(globalThis.FR = globalThis.FR || {});
